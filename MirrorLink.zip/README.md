# MirrorLink 0.3 (test build)

One APK, two roles. Install it on the phone AND on the Google TV.

## Build
Open this folder in Android Studio (Koala or newer), let Gradle sync, Run.
For the TV: enable Developer options → ADB debugging, `adb connect <tv-ip>`, then Run on that device.

## Use
1. TV: open MirrorLink → "Receive here". It shows its IP and advertises over mDNS.
2. Phone: open MirrorLink → tap the TV in the list (or type the IP) → pick a preset → Start mirroring → allow screen capture. It returns to your game.
3. TV: press any remote key to hide/show the stats bar. Back exits.
4. Stop from the phone notification.

## Test matrix (Wi-Fi vs wired)
- Wi-Fi 5/6 GHz, both on same router.
- Wired TV (Ethernet) + phone on Wi-Fi.
- Wired both: phone with USB-C Ethernet adapter, turn phone Wi-Fi OFF so Ethernet is the active route.
Compare the stats bar: rtt, loss, decode ms, fps. Start with 1080p60 H.264, then try HEVC.

## What's in it
- Surface-to-encoder zero-copy capture, low-latency/realtime encoder flags, CBR
- UDP, 1200-byte slices, paced keyframes
- Loss => receiver drops until next IDR and requests one; AIMD bitrate adaptation from receiver loss reports
- Rotation handling (encoder + decoder re-init), WifiLock low-latency, DSCP EF marking
- Stats: fps, Mbps, loss, RTT, decode time, drops

## Not yet (next milestones)
Audio (AudioPlaybackCapture + Opus), gamepad/touch input back-channel, FEC, pairing/encryption.
Untested on real hardware: compile and tune on your devices. If a device rejects "low-latency"/CBR keys it falls back automatically for CBR; tell me the logcat if anything fails.


## 0.2 changes
- Frame size: full screen, correct aspect, always inside a 16:9 box (1080 tall max) and aligned to the encoder's limits.
- Orientation: Auto (safe restart on rotate), Landscape lock, Portrait lock (no restarts = no freeze).
- Packet loss: NACK retransmit (fast LAN recovery) instead of waiting for a new keyframe; big frames are rate-paced.
- Wired mode: choose Network = Wired (Ethernet) to bind the stream to the Ethernet link (phone USB-C Ethernet adapter), larger packets, wired presets (40/50 Mbps).
- TV shows every IP (Ethernet / Wi-Fi) and the live stream size.
- Fixed debug key: later updates install over this one. First time, uninstall the old 0.1 app.


## 0.3 changes
- TV decoder: one decoder is kept across rotation (adaptive playback + flush); SPS/PPS sent in front of every keyframe; format retries and automatic surface rebuild if the TV rejects a format ("decoder failed 1920x864").
- Phone encoder: tries every encoder x full/75% size x 4 progressively simpler formats, so "Could not start: null" phones (e.g. Mi 10i) find a format they accept. Failure messages name the stage and are saved in the in-app Log.
- Settings (scrcpy style): max resolution, fps, bitrate slider, H.264/HEVC, CBR/VBR, adaptive bitrate, keyframe interval, orientation, TV scale (Fit / Fill / Stretch), network, buffer mode, stats on/off, quick profiles.
- TV remote: OK = cycle scale (Fit / Fill 16:9 / Stretch), Up = stats panel (off / basic / detailed), Back = exit.
- New UI on phone and TV. Crash handler + persistent log (Log button: view / copy / share / clear).
- Loss accounting no longer counts frames skipped while waiting for a keyframe (was making bitrate collapse); adaptive bitrate never goes below 40% of your setting.
