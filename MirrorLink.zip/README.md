# MirrorLink (test build)

One APK, two roles. Install it on the phone AND on the Google TV.

## Build
Open this folder in Android Studio (Koala or newer), let Gradle sync, Run.
For the TV: enable Developer options → ADB debugging, `adb connect <tv-ip>`, then Run on that device.

## Use
1. TV: open MirrorLink → "Receive here". It shows its IP and advertises over mDNS.
2. Phone: open MirrorLink → tap the TV in the list (or type the IP) → pick a preset → Start mirroring → allow screen capture. It returns to your game.
3. TV: press any remote key to hide/show the stats bar. Back exits.
4. Stop from the phone notification.

## Test matrix (Wi-Fi vs wired)
- Wi-Fi 5/6 GHz, both on same router.
- Wired TV (Ethernet) + phone on Wi-Fi.
- Wired both: phone with USB-C Ethernet adapter, turn phone Wi-Fi OFF so Ethernet is the active route.
Compare the stats bar: rtt, loss, decode ms, fps. Start with 1080p60 H.264, then try HEVC.

## What's in it
- Surface-to-encoder zero-copy capture, low-latency/realtime encoder flags, CBR
- UDP, 1200-byte slices, paced keyframes
- Loss => receiver drops until next IDR and requests one; AIMD bitrate adaptation from receiver loss reports
- Rotation handling (encoder + decoder re-init), WifiLock low-latency, DSCP EF marking
- Stats: fps, Mbps, loss, RTT, decode time, drops

## Not yet (next milestones)
Audio (AudioPlaybackCapture + Opus), gamepad/touch input back-channel, FEC, pairing/encryption.
Untested on real hardware: compile and tune on your devices. If a device rejects "low-latency"/CBR keys it falls back automatically for CBR; tell me the logcat if anything fails.
