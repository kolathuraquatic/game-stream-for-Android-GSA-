package com.mirrorlink

import java.nio.ByteBuffer

/** Wire format: 20-byte header + payload (<=1200 bytes), all over UDP. */
object Proto {
    const val MAGIC: Short = 0x4D4C
    const val T_CONFIG = 1   // payload: codec(1) w(2) h(2) csd...
    const val T_VIDEO = 2    // one slice of an encoded frame
    const val T_PING = 3     // receiver -> sender, ts = receiver clock (us)
    const val T_PONG = 4     // sender echoes ts
    const val T_STATS = 5    // receiver -> sender, payload: okFrames(4) lostFrames(4)
    const val T_REQ_KEY = 6  // receiver -> sender: please send an IDR frame
    const val F_KEY = 1
    const val HEADER = 20
    const val MAX_PAYLOAD = 1200
    const val PORT = 5600
    const val SERVICE_TYPE = "_mirrorlink._udp."

    fun write(b: ByteBuffer, type: Int, flags: Int, frameId: Int, idx: Int, count: Int, ts: Long) {
        b.clear()
        b.putShort(MAGIC); b.put(type.toByte()); b.put(flags.toByte())
        b.putInt(frameId); b.putShort(idx.toShort()); b.putShort(count.toShort()); b.putLong(ts)
    }
}

class Header(val type: Int, val flags: Int, val frameId: Int, val idx: Int, val count: Int, val ts: Long)

fun parseHeader(d: ByteArray, len: Int): Header? {
    if (len < Proto.HEADER) return null
    val b = ByteBuffer.wrap(d, 0, len)
    if (b.short != Proto.MAGIC) return null
    return Header(
        b.get().toInt(), b.get().toInt(), b.int,
        b.short.toInt() and 0xFFFF, b.short.toInt() and 0xFFFF, b.long
    )
}
