package com.mirrorlink

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView

/** Small dark "card" UI toolkit used by both screens (no XML needed). */
class UiKit(val ctx: Context) {
    companion object {
        val BG = 0xFF0E1117.toInt()
        val CARD = 0xFF171B24.toInt()
        val FIELD = 0xFF222836.toInt()
        val STROKE = 0xFF2B3242.toInt()
        val ACCENT = 0xFF5B8CFF.toInt()
        val ACCENT_DARK = 0xFF4A78E6.toInt()
        val TEXT = 0xFFE8ECF4.toInt()
        val SUB = 0xFF8A94A8.toInt()
        val GOOD = 0xFF3DDC84.toInt()
        val WARN = 0xFFFFC857.toInt()
        val BAD = 0xFFFF5C5C.toInt()
    }

    fun dp(v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    fun shape(fill: Int, radiusDp: Int = 14, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(radiusDp).toFloat()
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor)
        return g
    }

    fun text(s: String, sizeSp: Float = 15f, color: Int = TEXT, bold: Boolean = false): TextView {
        val t = TextView(ctx)
        t.text = s
        t.textSize = sizeSp
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    fun lp(top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.topMargin = dp(top)
        p.bottomMargin = dp(bottom)
        return p
    }

    fun card(title: String?): LinearLayout {
        val c = LinearLayout(ctx)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(14), dp(16), dp(16))
        c.background = shape(CARD, 18, STROKE, 1)
        if (title != null) {
            val t = text(title.uppercase(), 12f, SUB, true)
            t.letterSpacing = 0.08f
            c.addView(t, lp(bottom = 6))
        }
        return c
    }

    fun button(label: String, primary: Boolean, onClick: () -> Unit): Button {
        val fill = if (primary) ACCENT else FIELD
        val stroke = if (primary) ACCENT else STROKE
        val sl = StateListDrawable()
        sl.addState(intArrayOf(android.R.attr.state_focused), shape(fill, 14, Color.WHITE, 3))
        sl.addState(intArrayOf(android.R.attr.state_pressed), shape(if (primary) ACCENT_DARK else STROKE, 14))
        sl.addState(intArrayOf(), shape(fill, 14, stroke, 1))
        val b = Button(ctx)
        b.text = label
        b.setAllCaps(false)
        b.textSize = 15f
        b.setTextColor(if (primary) Color.WHITE else TEXT)
        b.background = sl
        b.stateListAnimator = null
        b.setPadding(dp(14), dp(12), dp(14), dp(12))
        b.setOnClickListener { onClick() }
        return b
    }

    fun pill(label: String, color: Int): TextView {
        val t = text(label, 15f, color, true)
        t.background = shape(FIELD, 20, STROKE, 1)
        t.setPadding(dp(14), dp(8), dp(14), dp(8))
        return t
    }

    class Row<T : View>(val view: View, val control: T)

    fun spinnerRow(label: String, items: List<String>, selected: Int): Row<Spinner> {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.VERTICAL
        row.addView(text(label, 12f, SUB), lp(top = 10, bottom = 4))
        val box = LinearLayout(ctx)
        box.background = shape(FIELD, 12, STROKE, 1)
        box.setPadding(dp(6), dp(2), dp(6), dp(2))
        val sp = Spinner(ctx)
        sp.adapter = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, items)
        sp.setSelection(selected.coerceIn(0, items.size - 1))
        box.addView(sp, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        row.addView(box, lp())
        return Row(row, sp)
    }

    fun seekRow(label: String, lo: Int, hi: Int, value: Int, fmt: (Int) -> String): Row<SeekBar> {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.VERTICAL
        val tv = text(fmt(value), 16f, TEXT, true)
        row.addView(text(label, 12f, SUB), lp(top = 10))
        row.addView(tv, lp(top = 2))
        val sb = SeekBar(ctx)
        sb.max = hi - lo
        sb.progress = (value - lo).coerceIn(0, hi - lo)
        sb.progressTintList = ColorStateList.valueOf(ACCENT)
        sb.thumbTintList = ColorStateList.valueOf(ACCENT)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { tv.text = fmt(p + lo) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        row.addView(sb, lp())
        return Row(row, sb)
    }

    fun switchRow(label: String, checked: Boolean): Row<Switch> {
        val sw = Switch(ctx)
        sw.text = label
        sw.setTextColor(TEXT)
        sw.textSize = 15f
        sw.isChecked = checked
        sw.setPadding(0, dp(10), 0, dp(6))
        return Row(sw, sw)
    }
}
