package com.mirrorlink

import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.Matrix
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Draws the phone screen (captured at its own native size into a SurfaceTexture) onto the encoder's input
 * surface at a FIXED canvas size. The stream shape therefore never depends on how a particular phone's
 * VirtualDisplay scales or crops, and rotating the phone needs no encoder / TV-decoder restart.
 * mode: 0 = fit (keep ratio, bars), 1 = fill (crop edges), 2 = stretch.
 */
class GlMirror(
    private val outSurface: Surface,
    private val outW: Int,
    private val outH: Int,
    srcW0: Int,
    srcH0: Int,
    private val mode: Int
) {
    private companion object {
        const val VS = "attribute vec4 aPos;\n" +
            "attribute vec2 aTex;\n" +
            "uniform mat4 uMvp;\n" +
            "uniform mat4 uTexMat;\n" +
            "varying vec2 vTex;\n" +
            "void main() {\n" +
            "  gl_Position = uMvp * aPos;\n" +
            "  vTex = (uTexMat * vec4(aTex, 0.0, 1.0)).xy;\n" +
            "}\n"
        const val FS = "#extension GL_OES_EGL_image_external : require\n" +
            "precision mediump float;\n" +
            "varying vec2 vTex;\n" +
            "uniform samplerExternalOES sTex;\n" +
            "void main() {\n" +
            "  gl_FragColor = texture2D(sTex, vTex);\n" +
            "}\n"
    }

    @Volatile private var srcW = srcW0
    @Volatile private var srcH = srcH0
    private val thread = HandlerThread("mirror-gl")
    private lateinit var handler: Handler
    private var display: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var context: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE
    private var program = 0
    private var texId = 0
    private var aPos = 0
    private var aTex = 0
    private var uMvp = 0
    private var uTexMat = 0
    private var st: SurfaceTexture? = null
    private var inSurface: Surface? = null
    private val texMat = FloatArray(16)
    private val mvp = FloatArray(16)
    private var lastDraw = 0L
    @Volatile private var running = false

    private val quad: FloatBuffer = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().also {
        // x, y, u, v
        it.put(floatArrayOf(-1f, -1f, 0f, 0f, 1f, -1f, 1f, 0f, -1f, 1f, 0f, 1f, 1f, 1f, 1f, 1f))
        it.position(0)
    }

    private val repeater = object : Runnable {
        override fun run() {
            if (!running) return
            if (SystemClock.elapsedRealtime() - lastDraw >= 90) draw(false)   // keep the encoder fed on a still screen
            handler.postDelayed(this, 50)
        }
    }

    /** Starts the GL thread; returns the Surface the capture VirtualDisplay must render into. */
    fun start(): Surface {
        thread.start()
        handler = Handler(thread.looper)
        val latch = CountDownLatch(1)
        var error: Throwable? = null
        handler.post {
            try { init() } catch (t: Throwable) { error = t }
            latch.countDown()
        }
        if (!latch.await(5, TimeUnit.SECONDS)) {
            stop()
            throw IllegalStateException("OpenGL setup timed out")
        }
        val err = error
        if (err != null) {
            stop()
            throw err
        }
        running = true
        handler.postDelayed(repeater, 100)
        return inSurface!!
    }

    /** The phone's screen size changed (rotation). */
    fun setSource(w: Int, h: Int) {
        handler.post {
            srcW = w; srcH = h
            try { st?.setDefaultBufferSize(w, h) } catch (_: Throwable) {}
        }
    }

    fun stop() {
        running = false
        try {
            if (this::handler.isInitialized) {
                val latch = CountDownLatch(1)
                handler.post {
                    try { release() } catch (_: Throwable) {}
                    latch.countDown()
                }
                latch.await(2, TimeUnit.SECONDS)
            }
        } catch (_: Throwable) {}
        try { thread.quitSafely() } catch (_: Throwable) {}
    }

    private fun init() {
        display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        check(display != EGL14.EGL_NO_DISPLAY) { "no EGL display" }
        val ver = IntArray(2)
        check(EGL14.eglInitialize(display, ver, 0, ver, 1)) { "EGL init failed" }
        val attribs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            0x3142, 1,   // EGL_RECORDABLE_ANDROID
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val num = IntArray(1)
        check(EGL14.eglChooseConfig(display, attribs, 0, configs, 0, 1, num, 0) && num[0] > 0) { "no EGL config" }
        val cfg = configs[0]
        context = EGL14.eglCreateContext(display, cfg, EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        check(context != EGL14.EGL_NO_CONTEXT) { "no EGL context" }
        eglSurface = EGL14.eglCreateWindowSurface(display, cfg, outSurface, intArrayOf(EGL14.EGL_NONE), 0)
        check(eglSurface != EGL14.EGL_NO_SURFACE) { "no EGL surface" }
        check(EGL14.eglMakeCurrent(display, eglSurface, eglSurface, context)) { "eglMakeCurrent failed" }

        program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, compile(GLES20.GL_VERTEX_SHADER, VS))
        GLES20.glAttachShader(program, compile(GLES20.GL_FRAGMENT_SHADER, FS))
        GLES20.glLinkProgram(program)
        val linked = IntArray(1)
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, linked, 0)
        check(linked[0] != 0) { "GL link failed: " + GLES20.glGetProgramInfoLog(program) }
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        aTex = GLES20.glGetAttribLocation(program, "aTex")
        uMvp = GLES20.glGetUniformLocation(program, "uMvp")
        uTexMat = GLES20.glGetUniformLocation(program, "uTexMat")

        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        texId = t[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        val s = SurfaceTexture(texId)
        s.setDefaultBufferSize(srcW, srcH)
        s.setOnFrameAvailableListener({ if (running) draw(true) }, handler)
        st = s
        inSurface = Surface(s)
        Matrix.setIdentityM(texMat, 0)
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        check(ok[0] != 0) { "GL shader failed: " + GLES20.glGetShaderInfoLog(s) }
        return s
    }

    private fun draw(newFrame: Boolean) {
        val s = st ?: return
        try {
            if (newFrame) {
                s.updateTexImage()
                s.getTransformMatrix(texMat)
            }
            GLES20.glViewport(0, 0, outW, outH)
            GLES20.glClearColor(0f, 0f, 0f, 1f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            val aS = srcW.toFloat() / srcH.toFloat()
            val aO = outW.toFloat() / outH.toFloat()
            var sx = 1f
            var sy = 1f
            if (mode == 0) {
                if (aS > aO) sy = aO / aS else sx = aS / aO
            } else if (mode == 1) {
                if (aS > aO) sx = aS / aO else sy = aO / aS
            }
            Matrix.setIdentityM(mvp, 0)
            Matrix.scaleM(mvp, 0, sx, sy, 1f)
            GLES20.glUseProgram(program)
            quad.position(0)
            GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, quad)
            GLES20.glEnableVertexAttribArray(aPos)
            quad.position(2)
            GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 16, quad)
            GLES20.glEnableVertexAttribArray(aTex)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
            GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
            GLES20.glUniformMatrix4fv(uTexMat, 1, false, texMat, 0)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            EGLExt.eglPresentationTimeANDROID(display, eglSurface, System.nanoTime())
            EGL14.eglSwapBuffers(display, eglSurface)
            lastDraw = SystemClock.elapsedRealtime()
        } catch (t: Throwable) {
            Diag.log("gl draw: $t")
        }
    }

    private fun release() {
        handler.removeCallbacksAndMessages(null)
        try { st?.setOnFrameAvailableListener(null) } catch (_: Throwable) {}
        try { inSurface?.release() } catch (_: Throwable) {}
        try { st?.release() } catch (_: Throwable) {}
        st = null; inSurface = null
        if (display != EGL14.EGL_NO_DISPLAY) {
            try { EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT) } catch (_: Throwable) {}
            if (eglSurface != EGL14.EGL_NO_SURFACE) try { EGL14.eglDestroySurface(display, eglSurface) } catch (_: Throwable) {}
            if (context != EGL14.EGL_NO_CONTEXT) try { EGL14.eglDestroyContext(display, context) } catch (_: Throwable) {}
            try { EGL14.eglTerminate(display) } catch (_: Throwable) {}
        }
        display = EGL14.EGL_NO_DISPLAY; context = EGL14.EGL_NO_CONTEXT; eglSurface = EGL14.EGL_NO_SURFACE
    }
}
