package com.mirrorlink

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import java.net.Inet4Address

/** mDNS: the TV advertises itself, the phone lists TVs. Manual IP entry is the fallback. */
@Suppress("DEPRECATION")
class Discovery(ctx: Context) {
    private val nsd = ctx.applicationContext.getSystemService(Context.NSD_SERVICE) as NsdManager
    private var reg: NsdManager.RegistrationListener? = null
    private var disc: NsdManager.DiscoveryListener? = null

    fun advertise(name: String) {
        val info = NsdServiceInfo().apply {
            serviceName = "MirrorLink-$name"; serviceType = Proto.SERVICE_TYPE; port = Proto.PORT
        }
        val l = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(i: NsdServiceInfo) {}
            override fun onRegistrationFailed(i: NsdServiceInfo, e: Int) {}
            override fun onServiceUnregistered(i: NsdServiceInfo) {}
            override fun onUnregistrationFailed(i: NsdServiceInfo, e: Int) {}
        }
        reg = l
        nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, l)
    }

    fun discover(onFound: (name: String, ip: String) -> Unit) {
        val resolver = object : NsdManager.ResolveListener {
            override fun onResolveFailed(i: NsdServiceInfo, e: Int) {}
            override fun onServiceResolved(r: NsdServiceInfo) {
                val a = r.host
                if (a !is Inet4Address) return      // IPv6 link-local addresses do not work for the stream
                val ip = a.hostAddress ?: return
                onFound(r.serviceName, ip)
            }
        }
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onStartDiscoveryFailed(t: String, e: Int) {}
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
            override fun onServiceLost(i: NsdServiceInfo) {}
            override fun onServiceFound(i: NsdServiceInfo) {
                try { nsd.resolveService(i, resolver) } catch (_: Exception) {}
            }
        }
        disc = l
        nsd.discoverServices(Proto.SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, l)
    }

    fun stop() {
        try { reg?.let { nsd.unregisterService(it) } } catch (_: Exception) {}
        try { disc?.let { nsd.stopServiceDiscovery(it) } } catch (_: Exception) {}
        reg = null; disc = null
    }
}
