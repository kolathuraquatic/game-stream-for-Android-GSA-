package com.mirrorlink

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager

/** mDNS: the TV advertises itself, the phone lists TVs. Manual IP entry is the fallback. */
@Suppress("DEPRECATION")
class Discovery(ctx: Context) {
    private val nsd = ctx.applicationContext.getSystemService(Context.NSD_SERVICE) as NsdManager
    private var reg: NsdManager.RegistrationListener? = null
    private var disc: NsdManager.DiscoveryListener? = null
    private var multicastLock: WifiManager.MulticastLock? = null

    // Android filters multicast packets while the screen is active unless an app
    // holds a MulticastLock. Without it mDNS discovery can silently return no TVs.
    private fun acquireMulticast() {
        if (multicastLock?.isHeld == true) return
        try {
            val wifi = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            multicastLock = wifi.createMulticastLock("MirrorLink-mdns").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (_: Throwable) { }
    }

    fun advertise(name: String) {
        acquireMulticast()
        val info = NsdServiceInfo().apply {
            serviceName = "MirrorLink-$name"; serviceType = Proto.SERVICE_TYPE; port = Proto.PORT
        }
        val l = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(i: NsdServiceInfo) {}
            override fun onRegistrationFailed(i: NsdServiceInfo, e: Int) {}
            override fun onServiceUnregistered(i: NsdServiceInfo) {}
            override fun onUnregistrationFailed(i: NsdServiceInfo, e: Int) {}
        }
        reg = l
        nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, l)
    }

    fun discover(onFound: (name: String, ip: String) -> Unit) {
        acquireMulticast()
        val resolver = object : NsdManager.ResolveListener {
            override fun onResolveFailed(i: NsdServiceInfo, e: Int) {}
            override fun onServiceResolved(r: NsdServiceInfo) {
                val ip = r.host?.hostAddress ?: return
                onFound(r.serviceName, ip)
            }
        }
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onStartDiscoveryFailed(t: String, e: Int) {}
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
            override fun onServiceLost(i: NsdServiceInfo) {}
            override fun onServiceFound(i: NsdServiceInfo) {
                try { nsd.resolveService(i, resolver) } catch (_: Exception) {}
            }
        }
        disc = l
        nsd.discoverServices(Proto.SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, l)
    }

    fun stop() {
        try { reg?.let { nsd.unregisterService(it) } } catch (_: Exception) {}
        try { disc?.let { nsd.stopServiceDiscovery(it) } } catch (_: Exception) {}
        reg = null; disc = null
        try { multicastLock?.let { if (it.isHeld) it.release() } } catch (_: Throwable) {}
        multicastLock = null
    }
}
