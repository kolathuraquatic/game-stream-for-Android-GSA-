package com.mirrorlink

import android.app.Activity
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.net.Inet4Address
import java.net.NetworkInterface
import kotlin.math.max
import kotlin.math.min

class ReceiverActivity : Activity(), SurfaceHolder.Callback, ReceiverListener {
    private lateinit var ui: UiKit
    private lateinit var root: FrameLayout
    private lateinit var sv: SurfaceView
    private lateinit var idle: LinearLayout
    private lateinit var idleStatus: TextView
    private lateinit var hud: LinearLayout
    private lateinit var hudDot: TextView
    private lateinit var hudLine1: TextView
    private lateinit var hudLine2: TextView
    private lateinit var toastTv: TextView
    private var rx: Receiver? = null
    private var disc: Discovery? = null
    private val handler = Handler(Looper.getMainLooper())

    private val scaleNames = listOf("Fit (keep ratio)", "Fill 16:9 (crop edges)", "Stretch to 16:9")
    private var vw = 16
    private var vh = 9
    private var scaleMode = 0
    private var hudMode = 1               // 0 hidden, 1 basic, 2 detailed
    private var senderScale = -1
    private var senderStats = -1
    private var lastStats: Stats? = null
    private var gotVideo = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        ui = UiKit(this)
        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        sv = SurfaceView(this)
        root.addView(sv, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))

        // idle / status card
        idle = LinearLayout(this)
        idle.orientation = LinearLayout.VERTICAL
        idle.gravity = Gravity.CENTER_HORIZONTAL
        idle.background = ui.shape(0xE60E1117.toInt(), 24, UiKit.STROKE, 1)
        idle.setPadding(ui.dp(36), ui.dp(28), ui.dp(36), ui.dp(28))
        idle.addView(ui.text("MirrorLink", 34f, UiKit.TEXT, true))
        idle.addView(ui.text("Ready to receive", 16f, UiKit.SUB), ui.lp(top = 2, bottom = 14))
        idleStatus = ui.text("Waiting for your phone…", 18f, UiKit.ACCENT, true)
        idle.addView(idleStatus, ui.lp(bottom = 14))
        for (a in addresses()) idle.addView(ui.pill(a, UiKit.TEXT), ui.lp(bottom = 8))
        idle.addView(ui.text("Phone: MirrorLink → enter one of these IPs → Start", 14f, UiKit.SUB), ui.lp(top = 8))
        idle.addView(ui.text("OK = scale mode   ·   ↑ = stats   ·   Back = exit", 13f, UiKit.SUB), ui.lp(top = 4))
        root.addView(idle, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        // HUD
        hud = LinearLayout(this)
        hud.orientation = LinearLayout.VERTICAL
        hud.background = ui.shape(0xB3000000.toInt(), 14)
        hud.setPadding(ui.dp(14), ui.dp(8), ui.dp(14), ui.dp(8))
        val line = LinearLayout(this)
        line.orientation = LinearLayout.HORIZONTAL
        hudDot = ui.text("●", 16f, UiKit.GOOD)
        hudLine1 = ui.text("", 14f, UiKit.TEXT, true)
        hudLine1.setPadding(ui.dp(8), 0, 0, 0)
        line.addView(hudDot)
        line.addView(hudLine1)
        hudLine2 = ui.text("", 12f, UiKit.SUB)
        hud.addView(line)
        hud.addView(hudLine2)
        hud.visibility = View.GONE
        val hlp = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START)
        hlp.setMargins(ui.dp(16), ui.dp(12), 0, 0)
        root.addView(hud, hlp)

        toastTv = ui.text("", 18f, UiKit.TEXT, true)
        toastTv.background = ui.shape(0xCC000000.toInt(), 20)
        toastTv.setPadding(ui.dp(20), ui.dp(10), ui.dp(20), ui.dp(10))
        toastTv.visibility = View.GONE
        val tlp = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        tlp.bottomMargin = ui.dp(48)
        root.addView(toastTv, tlp)

        setContentView(root)
        root.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        sv.holder.addCallback(this)
        root.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> fit() }
        try { disc = Discovery(this).also { it.advertise(Build.MODEL ?: "TV") } } catch (_: Throwable) {}
    }

    override fun surfaceCreated(h: SurfaceHolder) {
        rx = Receiver(applicationContext, h.surface, this).also { it.start() }
    }
    override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {}
    override fun surfaceDestroyed(h: SurfaceHolder) { rx?.stop(); rx = null }

    override fun onDestroy() {
        try { disc?.stop() } catch (_: Throwable) {}
        rx?.stop()
        super.onDestroy()
    }

    // ---- ReceiverListener (called from background threads) ----
    override fun onVideoSize(w: Int, h: Int) {
        runOnUiThread { vw = w; vh = h; gotVideo = true; idle.visibility = View.GONE; fit() }
    }

    override fun onSenderPrefs(scale: Int, showStats: Boolean) {
        runOnUiThread {
            if (scale != senderScale) { senderScale = scale; scaleMode = scale.coerceIn(0, 2); fit() }
            val s = if (showStats) 1 else 0
            if (s != senderStats) { senderStats = s; hudMode = if (showStats) 1 else 0; renderHud() }
        }
    }

    override fun onStats(s: Stats) {
        runOnUiThread {
            lastStats = s
            if (s.fps > 0) idle.visibility = View.GONE
            else if (gotVideo) { idleStatus.setTextColor(UiKit.WARN); idleStatus.text = "Stream paused - waiting for the phone…"; idle.visibility = View.VISIBLE }
            renderHud()
        }
    }

    override fun onError(msg: String) {
        runOnUiThread { idleStatus.setTextColor(UiKit.BAD); idleStatus.text = msg; idle.visibility = View.VISIBLE }
    }

    override fun onSurfaceReset() {
        runOnUiThread {
            sv.visibility = View.INVISIBLE
            handler.postDelayed({ sv.visibility = View.VISIBLE }, 400)
        }
    }

    // ---- UI helpers ----
    private fun fit() {
        val pw = root.width
        val ph = root.height
        if (pw == 0 || ph == 0) return
        val lp = when (scaleMode) {
            2 -> FrameLayout.LayoutParams(pw, ph, Gravity.CENTER)
            1 -> {
                val s = max(pw.toFloat() / vw, ph.toFloat() / vh)
                FrameLayout.LayoutParams((vw * s).toInt() + 1, (vh * s).toInt() + 1, Gravity.CENTER)
            }
            else -> {
                val s = min(pw.toFloat() / vw, ph.toFloat() / vh)
                FrameLayout.LayoutParams((vw * s).toInt(), (vh * s).toInt(), Gravity.CENTER)
            }
        }
        val cur = sv.layoutParams
        if (cur.width != lp.width || cur.height != lp.height) sv.layoutParams = lp
    }

    private fun renderHud() {
        val s = lastStats
        if (hudMode == 0 || s == null || s.fps == 0) { hud.visibility = View.GONE; return }
        hud.visibility = View.VISIBLE
        val color = if (s.lossPct < 0.5f && s.rttMs < 25f) UiKit.GOOD else if (s.lossPct < 3f) UiKit.WARN else UiKit.BAD
        hudDot.setTextColor(color)
        hudLine1.text = "%dx%d  ·  %d fps  ·  %.1f Mbps".format(s.w, s.h, s.fps, s.mbps)
        if (hudMode == 2) {
            hudLine2.visibility = View.VISIBLE
            hudLine2.text = "loss %.1f%%  ·  rtt %.1f ms  ·  decode %.1f ms  ·  nack %d  ·  resync %d  ·  %s"
                .format(s.lossPct, s.rttMs, s.decMs, s.nack, s.resync, scaleNames[scaleMode])
        } else hudLine2.visibility = View.GONE
    }

    private fun flash(msg: String) {
        toastTv.text = msg
        toastTv.visibility = View.VISIBLE
        handler.removeCallbacks(hideToast)
        handler.postDelayed(hideToast, 1800)
    }
    private val hideToast = Runnable { toastTv.visibility = View.GONE }

    override fun onKeyDown(k: Int, e: KeyEvent): Boolean {
        when (k) {
            KeyEvent.KEYCODE_BACK -> { finish(); return true }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_BUTTON_A -> {
                scaleMode = (scaleMode + 1) % 3
                fit(); renderHud(); flash("Scale: ${scaleNames[scaleMode]}")
                return true
            }
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_INFO, KeyEvent.KEYCODE_BUTTON_Y -> {
                hudMode = (hudMode + 1) % 3
                renderHud()
                return true
            }
        }
        return super.onKeyDown(k, e)
    }

    private fun addresses(): List<String> {
        val out = ArrayList<String>()
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()?.toList() ?: emptyList()) {
                if (!ni.isUp || ni.isLoopback) continue
                val ip = ni.inetAddresses.toList().firstOrNull { it is Inet4Address }?.hostAddress ?: continue
                val label = when {
                    ni.name.startsWith("eth") -> "Ethernet"
                    ni.name.startsWith("wlan") -> "Wi-Fi"
                    else -> ni.name
                }
                out.add("$label   $ip")
            }
        } catch (_: Exception) {}
        if (out.isEmpty()) out.add("No network connection")
        return out
    }
}
