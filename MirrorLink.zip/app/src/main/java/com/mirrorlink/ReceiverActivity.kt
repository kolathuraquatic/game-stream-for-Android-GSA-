package com.mirrorlink

import android.app.Activity
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import java.net.Inet4Address
import java.net.NetworkInterface
import kotlin.math.min

class ReceiverActivity : Activity(), SurfaceHolder.Callback {
    private lateinit var root: FrameLayout
    private lateinit var sv: SurfaceView
    private lateinit var tv: TextView
    private var rx: Receiver? = null
    private var disc: Discovery? = null
    private var vw = 16
    private var vh = 9
    private var gotVideo = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        sv = SurfaceView(this)
        root.addView(sv, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        tv = TextView(this).apply {
            setTextColor(Color.WHITE); setBackgroundColor(0x99000000.toInt()); textSize = 14f
            setPadding(24, 12, 24, 12)
            text = "Waiting for phone…  (port ${Proto.PORT})\n${addresses()}"
        }
        root.addView(tv, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))
        setContentView(root)
        root.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        sv.holder.addCallback(this)
        root.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> fit() }
        disc = Discovery(this).also { it.advertise(Build.MODEL ?: "TV") }
    }

    override fun surfaceCreated(h: SurfaceHolder) {
        rx = Receiver(applicationContext, h.surface, ::onVideoSize, ::onStats).also { it.start() }
    }
    override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {}
    override fun surfaceDestroyed(h: SurfaceHolder) { rx?.stop(); rx = null }

    override fun onDestroy() { disc?.stop(); rx?.stop(); super.onDestroy() }

    private fun onVideoSize(w: Int, h: Int) = runOnUiThread { vw = w; vh = h; gotVideo = true; fit() }

    private fun onStats(s: String) = runOnUiThread { if (gotVideo) tv.text = s }

    private fun fit() {
        val pw = root.width; val ph = root.height
        if (pw == 0 || ph == 0) return
        val s = min(pw.toFloat() / vw, ph.toFloat() / vh)
        val lp = FrameLayout.LayoutParams((vw * s).toInt(), (vh * s).toInt(), Gravity.CENTER)
        if (sv.layoutParams.width != lp.width || sv.layoutParams.height != lp.height) sv.layoutParams = lp
    }

    override fun onKeyDown(k: Int, e: KeyEvent): Boolean {
        if (k == KeyEvent.KEYCODE_BACK) { finish(); return true }
        tv.visibility = if (tv.visibility == View.VISIBLE) View.GONE else View.VISIBLE  // toggle stats overlay
        return true
    }

    private fun addresses(): String {
        val out = ArrayList<String>()
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()?.toList() ?: emptyList()) {
                if (!ni.isUp || ni.isLoopback) continue
                val ip = ni.inetAddresses.toList().firstOrNull { it is Inet4Address }?.hostAddress ?: continue
                val label = when {
                    ni.name.startsWith("eth") -> "Ethernet"
                    ni.name.startsWith("wlan") -> "Wi-Fi"
                    else -> ni.name
                }
                out.add("$label: $ip")
            }
        } catch (_: Exception) {}
        return if (out.isEmpty()) "No network" else out.joinToString("\n")
    }
}
