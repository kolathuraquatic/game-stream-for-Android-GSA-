package com.mirrorlink

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Tiny persistent log so crashes and start failures can be read (and shared) from the app itself. */
object Diag {
    private var file: File? = null
    private val lines = ArrayList<String>()
    private var lastMsg = ""
    private var lastAt = 0L

    @Synchronized
    fun init(ctx: Context) {
        file = File(ctx.filesDir, "mirrorlink.log")
        try {
            val f = file
            if (f != null && f.exists()) lines.addAll(f.readLines().takeLast(300))
        } catch (_: Throwable) {}
    }

    @Synchronized
    fun log(msg: String) {
        val now = System.currentTimeMillis()
        if (msg == lastMsg && now - lastAt < 2000) return
        lastMsg = msg; lastAt = now
        val t = SimpleDateFormat("MM-dd HH:mm:ss", Locale.US).format(Date(now))
        for (l in msg.split("\n")) lines.add("$t $l")
        while (lines.size > 300) lines.removeAt(0)
        Log.w("MirrorLink", msg)
        try { file?.writeText(lines.joinToString("\n")) } catch (_: Throwable) {}
    }

    @Synchronized
    fun read(): String = if (lines.isEmpty()) "(log is empty)" else lines.joinToString("\n")

    @Synchronized
    fun clear() {
        lines.clear()
        try { file?.delete() } catch (_: Throwable) {}
    }

    @Synchronized
    fun hasCrash(): Boolean = lines.any { it.contains("CRASH") }

    fun installCrashHandler() {
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { log("CRASH in thread ${t.name}:\n" + Log.getStackTraceString(e)) } catch (_: Throwable) {}
            prev?.uncaughtException(t, e)
        }
    }
}
