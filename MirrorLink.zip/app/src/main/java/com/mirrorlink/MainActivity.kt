package com.mirrorlink

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var ui: UiKit
    private lateinit var host: EditText
    private lateinit var resSp: Spinner
    private lateinit var fpsSp: Spinner
    private lateinit var codecSp: Spinner
    private lateinit var modeSp: Spinner
    private lateinit var orientSp: Spinner
    private lateinit var scaleSp: Spinner
    private lateinit var netSp: Spinner
    private lateinit var bufSp: Spinner
    private lateinit var keySp: Spinner
    private lateinit var bitrateSb: SeekBar
    private lateinit var adaptiveSw: Switch
    private lateinit var statsSw: Switch
    private lateinit var startBtn: Button
    private lateinit var devRow: LinearLayout
    private var disc: Discovery? = null
    private val seen = HashSet<String>()

    private val edges = intArrayOf(1280, 1920, 2560, 3840)
    private val fpsList = intArrayOf(30, 60, 90, 120)
    private val keyList = intArrayOf(1, 2, 4, 8)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        // On Android TV, launch the receiver automatically. Previously the TV opened
        // the sender/settings screen and did not bind UDP/5600 until the user found
        // and pressed the separate TV-mode button.
        val isTv = packageManager.hasSystemFeature("android.software.leanback") ||
            !packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_TOUCHSCREEN) ||
            (resources.configuration.uiMode and Configuration.UI_MODE_TYPE_MASK) == Configuration.UI_MODE_TYPE_TELEVISION
        if (isTv) {
            startActivity(Intent(this, ReceiverActivity::class.java))
            finish()
            return
        }
        ui = UiKit(this)
        val st = StreamSettings.load(this)
        window.statusBarColor = UiKit.BG
        window.navigationBarColor = UiKit.BG

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(ui.dp(16), ui.dp(22), ui.dp(16), ui.dp(32))

        col.addView(ui.text("MirrorLink", 30f, UiKit.TEXT, true))
        col.addView(ui.text("Low-latency screen mirroring to your TV", 14f, UiKit.SUB), ui.lp(bottom = 14))

        if (Diag.hasCrash()) {
            val warn = ui.text("The app crashed last time. Tap “Log” below to see why and send it to me.", 13f, UiKit.WARN)
            warn.background = ui.shape(0x33FFC857, 12, UiKit.WARN, 1)
            warn.setPadding(ui.dp(12), ui.dp(10), ui.dp(12), ui.dp(10))
            col.addView(warn, ui.lp(bottom = 12))
        }

        // ---- Receiver ----
        val c1 = ui.card("Send to")
        host = EditText(this)
        host.hint = "TV IP address (shown on the TV)"
        host.setHintTextColor(UiKit.SUB)
        host.setTextColor(UiKit.TEXT)
        host.setText(st.host)
        host.setSingleLine()
        host.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        host.background = ui.shape(UiKit.FIELD, 12, UiKit.STROKE, 1)
        host.setPadding(ui.dp(14), ui.dp(12), ui.dp(14), ui.dp(12))
        c1.addView(host, ui.lp(bottom = 8))
        c1.addView(ui.text("Found on your network (tap to use):", 12f, UiKit.SUB), ui.lp(top = 2, bottom = 4))
        devRow = LinearLayout(this)
        devRow.orientation = LinearLayout.HORIZONTAL
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(devRow)
        c1.addView(hs, ui.lp())
        col.addView(c1, ui.lp(bottom = 12))

        // ---- Profiles ----
        val c2 = ui.card("Quick profile")
        val r1 = LinearLayout(this); r1.orientation = LinearLayout.HORIZONTAL
        val r2 = LinearLayout(this); r2.orientation = LinearLayout.HORIZONTAL
        fun chip(label: String, idx: Int, row: LinearLayout) {
            val btn = ui.button(label, false) { profile(idx) }
            val p = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            p.setMargins(ui.dp(3), ui.dp(3), ui.dp(3), ui.dp(3))
            row.addView(btn, p)
        }
        chip("Lowest latency", 0, r1); chip("Balanced", 1, r1)
        chip("Best quality", 2, r2); chip("Wired max", 3, r2)
        c2.addView(r1); c2.addView(r2)
        col.addView(c2, ui.lp(bottom = 12))

        // ---- Video ----
        val c3 = ui.card("Video")
        val res = ui.spinnerRow("Max resolution (like scrcpy -m)", listOf("720p  (1280)", "1080p  (1920)", "1440p  (2560)", "4K  (3840)"), edges.indexOf(st.edge))
        resSp = res.control
        val fps = ui.spinnerRow("Frame rate", listOf("30 fps", "60 fps", "90 fps", "120 fps"), fpsList.indexOf(st.fps))
        fpsSp = fps.control
        val br = ui.seekRow("Bitrate (like scrcpy -b)", 2, 100, st.mbps) { "$it Mbps" }
        bitrateSb = br.control
        val codec = ui.spinnerRow("Codec", listOf("H.264  (most compatible)", "HEVC / H.265  (more efficient)"), if (st.hevc) 1 else 0)
        codecSp = codec.control
        val mode = ui.spinnerRow("Bitrate mode", listOf("CBR  (steady, best for Wi-Fi)", "VBR  (quality first)"), if (st.cbr) 0 else 1)
        modeSp = mode.control
        val ad = ui.switchRow("Adaptive bitrate (lowers quality only if the link struggles)", st.adaptive)
        adaptiveSw = ad.control
        val key = ui.spinnerRow("Keyframe interval", listOf("1 s", "2 s", "4 s", "8 s"), keyList.indexOf(st.iframe))
        keySp = key.control
        for (v in listOf(res.view, fps.view, br.view, codec.view, mode.view, ad.view, key.view)) c3.addView(v)
        col.addView(c3, ui.lp(bottom = 12))

        // ---- Display ----
        val c4 = ui.card("Display on TV")
        val ori = ui.spinnerRow("Phone orientation", listOf("Auto (follows rotation)", "Landscape lock (best for games)", "Portrait lock"), st.orient)
        orientSp = ori.control
        val sc = ui.spinnerRow("Fit to TV 16:9", listOf("Fit  (keep ratio, thin bars)", "Fill  (crop edges, no bars)", "Stretch  (fill 16:9, distorts)"), st.scale)
        scaleSp = sc.control
        val sw = ui.switchRow("Show stats on TV", st.showStats)
        statsSw = sw.control
        c4.addView(ori.view); c4.addView(sc.view); c4.addView(sw.view)
        c4.addView(ui.text("On the TV: OK button cycles the scale mode, ↑ cycles the stats panel.", 12f, UiKit.SUB), ui.lp(top = 6))
        col.addView(c4, ui.lp(bottom = 12))

        // ---- Connection ----
        val c5 = ui.card("Connection")
        val net = ui.spinnerRow("Network", listOf("Auto", "Wi-Fi only", "Wired (Ethernet adapter)"), st.net)
        netSp = net.control
        val buf = ui.spinnerRow("Buffer (smoothness vs latency)", listOf("Lowest latency", "Balanced", "Smooth (more buffer)"), st.buffer)
        bufSp = buf.control
        c5.addView(net.view); c5.addView(buf.view)
        col.addView(c5, ui.lp(bottom = 16))

        startBtn = ui.button("Start mirroring", true) { if (SenderService.active) stopStream() else startStream() }
        startBtn.textSize = 17f
        col.addView(startBtn, ui.lp(bottom = 8))
        col.addView(ui.button("Receive on this device (TV mode)", false) {
            startActivity(Intent(this, ReceiverActivity::class.java))
        }, ui.lp(bottom = 8))
        col.addView(ui.button("Log (errors / crash info)", false) { showLog() }, ui.lp())

        val sv = ScrollView(this)
        sv.setBackgroundColor(UiKit.BG)
        sv.addView(col)
        setContentView(sv)

        try {
            disc = Discovery(this).also {
                it.discover { name, ip ->
                    runOnUiThread {
                        if (seen.add(ip)) {
                            val chip = ui.button("$name  $ip", false) { host.setText(ip) }
                            devRow.addView(chip)
                        }
                    }
                }
            }
        } catch (_: Throwable) {}
    }

    override fun onResume() {
        super.onResume()
        startBtn.text = if (SenderService.active) "Stop mirroring" else "Start mirroring"
    }

    private fun collect(): StreamSettings = StreamSettings(
        host = host.text.toString().trim(),
        edge = edges[resSp.selectedItemPosition],
        fps = fpsList[fpsSp.selectedItemPosition],
        mbps = bitrateSb.progress + 2,
        hevc = codecSp.selectedItemPosition == 1,
        cbr = modeSp.selectedItemPosition == 0,
        adaptive = adaptiveSw.isChecked,
        orient = orientSp.selectedItemPosition,
        scale = scaleSp.selectedItemPosition,
        net = netSp.selectedItemPosition,
        buffer = bufSp.selectedItemPosition,
        iframe = keyList[keySp.selectedItemPosition],
        showStats = statsSw.isChecked
    )

    private fun show(s: StreamSettings) {
        resSp.setSelection(edges.indexOf(s.edge).coerceAtLeast(0))
        fpsSp.setSelection(fpsList.indexOf(s.fps).coerceAtLeast(0))
        bitrateSb.progress = (s.mbps - 2).coerceIn(0, 98)
        codecSp.setSelection(if (s.hevc) 1 else 0)
        modeSp.setSelection(if (s.cbr) 0 else 1)
        adaptiveSw.isChecked = s.adaptive
        keySp.setSelection(keyList.indexOf(s.iframe).coerceAtLeast(0))
        orientSp.setSelection(s.orient.coerceIn(0, 2))
        scaleSp.setSelection(s.scale.coerceIn(0, 2))
        netSp.setSelection(s.net.coerceIn(0, 2))
        bufSp.setSelection(s.buffer.coerceIn(0, 2))
        statsSw.isChecked = s.showStats
    }

    private fun profile(i: Int) {
        val s = collect()
        when (i) {
            0 -> { s.edge = 1280; s.fps = 60; s.mbps = 10; s.hevc = false; s.cbr = true; s.adaptive = true; s.buffer = 0; s.iframe = 4 }
            1 -> { s.edge = 1920; s.fps = 60; s.mbps = 20; s.hevc = false; s.cbr = true; s.adaptive = true; s.buffer = 0; s.iframe = 4 }
            2 -> { s.edge = 1920; s.fps = 60; s.mbps = 35; s.hevc = true; s.cbr = false; s.adaptive = true; s.buffer = 1; s.iframe = 4 }
            else -> { s.edge = 2560; s.fps = 60; s.mbps = 60; s.hevc = true; s.cbr = true; s.adaptive = false; s.buffer = 0; s.net = 2; s.iframe = 4 }
        }
        show(s)
    }

    private fun startStream() {
        val s = collect()
        if (s.host.isEmpty()) { Toast.makeText(this, "Enter the TV's IP address first", Toast.LENGTH_SHORT).show(); return }
        s.save(this)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 0)
        try {
            startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 1)
        } catch (t: Throwable) {
            Diag.log("capture intent failed: $t")
            Toast.makeText(this, "Screen capture unavailable: ${t.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopStream() {
        startService(Intent(this, SenderService::class.java).setAction(SenderService.ACTION_STOP))
        startBtn.text = "Start mirroring"
    }

    @Deprecated("simple result handling")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 1 || res != RESULT_OK || data == null) return
        try {
            val i = collect().putInto(Intent(this, SenderService::class.java))
                .putExtra("code", res).putExtra("data", data)
            startForegroundService(i)
            startBtn.text = "Stop mirroring"
            moveTaskToBack(true)   // back to your game
        } catch (t: Throwable) {
            Diag.log("service start failed: $t")
            Toast.makeText(this, "Could not start: ${t.javaClass.simpleName} ${t.message ?: ""}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showLog() {
        val tv = TextView(this)
        tv.text = Diag.read()
        tv.textSize = 11f
        tv.typeface = Typeface.MONOSPACE
        tv.setTextColor(Color.WHITE)
        tv.setTextIsSelectable(true)
        tv.setPadding(ui.dp(16), ui.dp(8), ui.dp(16), ui.dp(8))
        val scroll = ScrollView(this)
        scroll.addView(tv)
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("MirrorLink log")
            .setView(scroll)
            .setPositiveButton("Share") { _, _ ->
                val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, Diag.read())
                startActivity(Intent.createChooser(send, "Share log"))
            }
            .setNeutralButton("Copy") { _, _ ->
                getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("MirrorLink log", Diag.read()))
                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Clear") { _, _ -> Diag.clear() }
            .show()
    }

    override fun onDestroy() {
        try { disc?.stop() } catch (_: Throwable) {}
        super.onDestroy()
    }
}
