package com.mirrorlink

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private class Preset(val label: String, val edge: Int, val fps: Int, val hevc: Boolean, val mbps: Int) {
        override fun toString() = label
    }
    private val presets = listOf(
        Preset("1080p60 · H.264 · 20 Mbps", 1920, 60, false, 20),
        Preset("1080p60 · HEVC · 15 Mbps", 1920, 60, true, 15),
        Preset("720p60 · H.264 · 10 Mbps", 1280, 60, false, 10),
        Preset("1440p60 · HEVC · 30 Mbps", 2560, 60, true, 30),
        Preset("1080p90 · H.264 · 25 Mbps", 1920, 90, false, 25)
    )
    private lateinit var host: EditText
    private lateinit var spinner: Spinner
    private lateinit var list: LinearLayout
    private var disc: Discovery? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("m", Context.MODE_PRIVATE)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 48, 48, 48) }
        fun text(s: String, size: Float = 16f) = TextView(this).apply { text = s; textSize = size; setPadding(0, 16, 0, 8) }

        col.addView(text("MirrorLink", 28f))
        col.addView(Button(this).apply {
            text = "Receive here (TV / second device)"
            setOnClickListener { startActivity(Intent(this@MainActivity, ReceiverActivity::class.java)) }
        })
        col.addView(text("Send this screen to:"))
        host = EditText(this).apply { hint = "Receiver IP (e.g. 192.168.1.50)"; setText(prefs.getString("host", "")); setSingleLine() }
        col.addView(host)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(list)
        spinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, presets) }
        col.addView(spinner)
        col.addView(Button(this).apply {
            text = "Start mirroring"
            setOnClickListener {
                if (host.text.isBlank()) { Toast.makeText(context, "Enter receiver IP", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                prefs.edit().putString("host", host.text.toString().trim()).apply()
                if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 0)
                startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 1)
            }
        })
        col.addView(Button(this).apply {
            text = "Stop"
            setOnClickListener { startService(Intent(this@MainActivity, SenderService::class.java).setAction(SenderService.ACTION_STOP)) }
        })
        setContentView(ScrollView(this).apply { addView(col) })

        disc = Discovery(this).also {
            it.discover { name, ip ->
                runOnUiThread {
                    list.addView(Button(this).apply {
                        text = "$name  ($ip)"
                        setOnClickListener { host.setText(ip) }
                    })
                }
            }
        }
    }

    @Deprecated("simple result handling")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 1 || res != RESULT_OK || data == null) return
        val p = presets[spinner.selectedItemPosition]
        startForegroundService(
            Intent(this, SenderService::class.java)
                .putExtra("code", res).putExtra("data", data)
                .putExtra("host", host.text.toString().trim())
                .putExtra("edge", p.edge).putExtra("fps", p.fps)
                .putExtra("hevc", p.hevc).putExtra("mbps", p.mbps)
        )
        moveTaskToBack(true)   // go back to your game
    }

    override fun onDestroy() { disc?.stop(); super.onDestroy() }
}
