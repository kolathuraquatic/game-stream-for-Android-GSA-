package com.mirrorlink

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.nio.ByteBuffer

class ProbeResult(val ok: Boolean, val text: String)

/** Network helpers: pick the Wi-Fi/Ethernet link that reaches the TV, and a quick "is the TV answering?" probe. */
@Suppress("DEPRECATION")
object Net {
    /** Wi-Fi/Ethernet network with a local route to [dest] (else any Wi-Fi/Ethernet). Never pure mobile data. */
    fun bestNetwork(ctx: Context, dest: InetAddress, mode: Int): Network? {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        var onLink: Network? = null
        var anyLan: Network? = null
        for (n in cm.allNetworks) {
            val caps = cm.getNetworkCapabilities(n) ?: continue
            val eth = caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
            val wifi = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
            if (!eth && !wifi) continue
            if (mode == 1 && !wifi) continue
            if (mode == 2 && !eth) continue
            val lp = cm.getLinkProperties(n)
            val matches = lp != null && lp.routes.any { !it.isDefaultRoute && it.matches(dest) }
            if (matches && onLink == null) onLink = n
            if (anyLan == null) anyLan = n
        }
        return onLink ?: anyLan
    }

    fun isEthernet(ctx: Context, n: Network?): Boolean {
        if (n == null) return false
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        return cm.getNetworkCapabilities(n)?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true
    }

    fun describe(ctx: Context, n: Network?): String {
        if (n == null) return "no Wi-Fi/Ethernet connection"
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val lp = cm.getLinkProperties(n)
        val ip = lp?.linkAddresses?.firstOrNull { it.address is Inet4Address }?.address?.hostAddress ?: "?"
        return (if (isEthernet(ctx, n)) "Ethernet " else "Wi-Fi ") + ip
    }

    /** Sends HELLO to the TV and waits for its answer. Run on a background thread. */
    fun probe(ctx: Context, host: String, mode: Int): ProbeResult {
        val dest = try { InetAddress.getByName(host) } catch (e: Exception) {
            return ProbeResult(false, "'$host' is not a valid address.")
        }
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val lan = bestNetwork(ctx, dest, mode)
        val def = cm.activeNetwork
        val defCaps = if (def != null) cm.getNetworkCapabilities(def) else null
        val cellular = defCaps != null && defCaps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) &&
            !defCaps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
        val info = "This phone: " + describe(ctx, lan) +
            (if (cellular) "\nAndroid is currently routing apps over mobile data." else "")
        val tries = ArrayList<Pair<String, Network?>>()
        if (lan != null) tries.add(Pair("Wi-Fi/LAN", lan))
        tries.add(Pair("default", null))
        for ((label, net) in tries) {
            val rtt = ping(dest, net)
            if (rtt >= 0f) return ProbeResult(true, "TV answered in %.1f ms (%s route).\n%s".format(rtt, label, info))
        }
        return ProbeResult(false, "No answer from $host.\n$info")
    }

    private fun ping(dest: InetAddress, net: Network?): Float {
        var s: DatagramSocket? = null
        try {
            s = DatagramSocket()
            net?.bindSocket(s)
            s.soTimeout = 500
            val out = ByteArray(Proto.HEADER)
            val ob = ByteBuffer.wrap(out)
            val inb = ByteArray(64)
            val rp = DatagramPacket(inb, inb.size)
            for (i in 0 until 3) {
                val t0 = System.nanoTime()
                Proto.write(ob, Proto.T_HELLO, 0, 0, 0, 1, t0 / 1000)
                s.send(DatagramPacket(out, out.size, dest, Proto.PORT))
                try {
                    rp.length = inb.size
                    s.receive(rp)
                    val h = parseHeader(inb, rp.length)
                    if (h != null && h.type == Proto.T_HELLO_ACK) return (System.nanoTime() - t0) / 1e6f
                } catch (_: SocketTimeoutException) {}
            }
        } catch (_: Exception) {
        } finally {
            try { s?.close() } catch (_: Exception) {}
        }
        return -1f
    }
}
