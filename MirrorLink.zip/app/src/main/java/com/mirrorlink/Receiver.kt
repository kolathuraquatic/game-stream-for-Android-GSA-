package com.mirrorlink

import android.content.Context
import android.media.MediaCodec
import android.media.MediaFormat
import android.net.wifi.WifiManager
import android.os.Process
import android.os.SystemClock
import android.view.Surface
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.SocketAddress
import java.net.SocketTimeoutException
import java.nio.ByteBuffer
import java.util.TreeMap
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

class Stats(
    val w: Int, val h: Int, val fps: Int, val mbps: Float, val lossPct: Float,
    val rttMs: Float, val decMs: Float, val nack: Int, val drops: Int, val resync: Int,
    val pkts: Int, val peer: String
)

interface ReceiverListener {
    fun onVideoSize(w: Int, h: Int)
    fun onSenderPrefs(scale: Int, showStats: Boolean)
    fun onStats(s: Stats)
    fun onError(msg: String)
    fun onSurfaceReset()
}

/**
 * TV side. UDP -> in-order reassembly window with NACK retransmit -> hardware decoder -> Surface.
 * One decoder is kept alive across rotations (adaptive playback + flush); if the TV rejects a
 * format, it retries with simpler settings and finally asks the UI to rebuild the surface.
 */
class Receiver(
    private val ctx: Context,
    private val surface: Surface,
    private val ui: ReceiverListener
) {
    private class Asm(val id: Int, val count: Int, val key: Boolean, val ts: Long, val first: Long) {
        val chunks = arrayOfNulls<ByteArray>(count)
        var got = 0
        var lastRx = first
        var lastNack = 0L
        var nacks = 0
    }

    private companion object {
        const val REORDER_NS = 2_000_000L
    }

    @Volatile private var running = false
    private var socket: DatagramSocket? = null
    @Volatile private var decoder: MediaCodec? = null
    private var decMime: String? = null
    private var curConfig: ByteArray? = null
    @Volatile private var senderAddr: SocketAddress? = null
    private var wifiLock: WifiManager.WifiLock? = null
    @Volatile private var restartDecoder = false
    private var lastDecoderFail = 0L
    private var lastSurfaceReset = 0L
    private var boxW = 1920
    private var boxH = 1088
    private var bufferMode = 0
    private var lastScale = -1
    private var lastStats = -1

    // reassembly (rx thread only)
    private val frames = TreeMap<Int, Asm>()
    private var nextId = -1
    private var maxId = -1
    private var needKey = true
    private var lastReq = 0L
    private var gapFor = -1
    private var gapTries = 0
    private var gapNackAt = 0L

    // stats
    private val okFrames = AtomicInteger()
    private val lostFrames = AtomicInteger()
    private val bytes = AtomicLong()
    private val rendered = AtomicInteger()
    private val dropped = AtomicInteger()
    private val nackPkts = AtomicInteger()
    private val resync = AtomicInteger()
    private val dataPkts = AtomicInteger()
    @Volatile private var rttMs = 0f
    @Volatile private var decMs = 0f
    @Volatile private var vidW = 0
    @Volatile private var vidH = 0
    private val arrivals = ConcurrentHashMap<Long, Long>()

    private val ctl = ByteArray(Proto.HEADER + 8)
    private val ctlBuf = ByteBuffer.wrap(ctl)

    private fun deadlineNs(): Long = when (bufferMode) {
        0 -> 15_000_000L      // lowest latency
        1 -> 40_000_000L      // balanced
        else -> 100_000_000L  // smooth
    }

    fun start() {
        running = true
        Thread(::rxMain, "mirror-rx").start()
    }

    fun stop() {
        running = false
        try { socket?.close() } catch (_: Throwable) {}
        try { decoder?.stop() } catch (_: Throwable) {}
        try { decoder?.release() } catch (_: Throwable) {}
        decoder = null
        try { wifiLock?.let { if (it.isHeld) it.release() } } catch (_: Throwable) {}
    }

    private fun rxMain() {
        var attempt = 0
        while (running) {
            try {
                val s = DatagramSocket(null)
                s.reuseAddress = true
                try { s.receiveBufferSize = 4 shl 20; s.trafficClass = 0xB8 } catch (_: Exception) {}
                s.soTimeout = 4
                s.bind(InetSocketAddress(Proto.PORT))
                socket = s
                break
            } catch (e: Exception) {
                Diag.log("bind failed #$attempt: $e")
                if (++attempt >= 10) { ui.onError("Can't open port ${Proto.PORT}: ${e.message}"); return }
                try { Thread.sleep(300) } catch (_: InterruptedException) { return }
            }
        }
        if (!running) { try { socket?.close() } catch (_: Throwable) {}; return }
        try {
            wifiLock = (ctx.getSystemService(Context.WIFI_SERVICE) as WifiManager)
                .createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "mirror-rx").also { it.acquire() }
        } catch (_: Throwable) {}
        Thread(::statsLoop, "mirror-stats").start()
        try { Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY) } catch (_: Throwable) {}
        rxLoop()
    }

    private fun replyHello(to: SocketAddress, ts: Long) {
        try {
            val out = ByteArray(Proto.HEADER)
            Proto.write(ByteBuffer.wrap(out), Proto.T_HELLO_ACK, 0, 0, 0, 1, ts)
            socket?.send(DatagramPacket(out, out.size, to))
        } catch (_: Exception) {}
    }

    private fun safeHousekeeping() {
        try { housekeeping() } catch (t: Throwable) { Diag.log("housekeeping: $t") }
    }

    private fun rxLoop() {
        val buf = ByteArray(2048)
        val p = DatagramPacket(buf, buf.size)
        var lastHk = 0L
        while (running) {
            p.length = buf.size
            try { socket!!.receive(p) }
            catch (e: SocketTimeoutException) { safeHousekeeping(); continue }
            catch (e: Exception) { break }
            try {
                val h = parseHeader(buf, p.length)
                if (h != null) {
                    when (h.type) {
                        Proto.T_HELLO -> {
                            if (h.flags and Proto.HELLO_STREAM != 0) senderAddr = p.socketAddress   // phone keep-alive: remember it
                            replyHello(p.socketAddress, h.ts)
                        }
                        Proto.T_CONFIG -> {
                            bytes.addAndGet(p.length.toLong()); dataPkts.incrementAndGet()
                            senderAddr = p.socketAddress; onConfig(buf, p.length)
                        }
                        Proto.T_VIDEO -> {
                            bytes.addAndGet(p.length.toLong()); dataPkts.incrementAndGet()
                            if (senderAddr == null) senderAddr = p.socketAddress
                            onVideo(h, buf, p.length)
                        }
                        Proto.T_PONG -> rttMs = (System.nanoTime() / 1000 - h.ts) / 1000f
                    }
                }
            } catch (t: Throwable) {
                Diag.log("rx: $t")
            }
            val now = System.nanoTime()
            if (now - lastHk > 2_000_000L) { lastHk = now; safeHousekeeping() }
        }
    }

    private fun onConfig(buf: ByteArray, len: Int) {
        val b = ByteBuffer.wrap(buf, Proto.HEADER, len - Proto.HEADER)
        if (b.remaining() < Proto.CFG_HDR) return
        val codecId = b.get().toInt()
        val w = b.short.toInt() and 0xFFFF
        val h = b.short.toInt() and 0xFFFF
        boxW = b.short.toInt() and 0xFFFF
        boxH = b.short.toInt() and 0xFFFF
        val scale = b.get().toInt()
        bufferMode = b.get().toInt()
        val stats = b.get().toInt()
        val csd = ByteArray(b.remaining()); b.get(csd)
        if (scale != lastScale || stats != lastStats) {
            lastScale = scale; lastStats = stats
            ui.onSenderPrefs(scale, stats != 0)
        }
        val mime = if (codecId == 1) MediaFormat.MIMETYPE_VIDEO_HEVC else MediaFormat.MIMETYPE_VIDEO_AVC
        val sameCsd = curConfig?.contentEquals(csd) == true
        if (decoder != null && decMime == mime && sameCsd) return
        curConfig = csd
        val sizeChanged = w != vidW || h != vidH
        vidW = w; vidH = h
        if (decoder == null || decMime != mime) {
            val now = SystemClock.elapsedRealtime()
            if (decoder == null && now - lastDecoderFail < 3000) return   // don't hammer a failing decoder
            startDecoder(mime, w, h)
        } else if (sizeChanged) {
            // same decoder keeps the surface; flush and let the next IDR (with SPS/PPS) re-init it
            try { decoder?.flush() } catch (t: Throwable) { Diag.log("flush failed: $t"); restartDecoder = true }
        }
        needKey = true
        ui.onVideoSize(w, h)
    }

    /** Tries progressively simpler formats; waits a bit between tries because a just-released decoder can still hold the surface. */
    private fun startDecoder(mime: String, w: Int, h: Int) {
        val old = decoder
        decoder = null
        try { old?.stop() } catch (_: Throwable) {}
        try { old?.release() } catch (_: Throwable) {}
        var last: Throwable? = null
        for (attempt in 0..3) {
            if (!running) return
            if (attempt > 0) try { Thread.sleep(150L * attempt) } catch (_: InterruptedException) { return }
            var c: MediaCodec? = null
            try {
                val f = MediaFormat.createVideoFormat(mime, w, h)
                if (attempt <= 1) { f.setInteger("low-latency", 1); f.setInteger(MediaFormat.KEY_PRIORITY, 0) }
                if (attempt == 0) f.setInteger(MediaFormat.KEY_OPERATING_RATE, 120)
                if (attempt <= 2) { f.setInteger(MediaFormat.KEY_MAX_WIDTH, boxW); f.setInteger(MediaFormat.KEY_MAX_HEIGHT, boxH) }
                val dc = MediaCodec.createDecoderByType(mime)
                c = dc
                dc.configure(f, surface, null, 0)
                dc.start()
                decoder = dc; decMime = mime
                Thread({ outLoop(dc) }, "mirror-dec").start()
                Diag.log("decoder ok (try $attempt) $mime ${w}x$h max ${boxW}x$boxH")
                return
            } catch (t: Throwable) {
                last = t
                try { c?.release() } catch (_: Throwable) {}
                Diag.log("decoder try $attempt failed ${w}x$h: $t")
            }
        }
        lastDecoderFail = SystemClock.elapsedRealtime()
        ui.onError("TV decoder failed ${w}x$h: ${last?.javaClass?.simpleName ?: ""} ${last?.message ?: ""}")
        if (lastDecoderFail - lastSurfaceReset > 5000) { lastSurfaceReset = lastDecoderFail; ui.onSurfaceReset() }
    }

    private fun onVideo(h: Header, buf: ByteArray, len: Int) {
        val now = System.nanoTime()
        if (nextId < 0) nextId = h.frameId
        if (h.frameId < nextId || h.count == 0 || h.idx >= h.count) return
        if (frames.size > 64) { frames.clear(); nextId = h.frameId; needKey = true; requestKey() }
        var a = frames[h.frameId]
        if (a == null) {
            a = Asm(h.frameId, h.count, h.flags and Proto.F_KEY != 0, h.ts, now)
            frames[h.frameId] = a
            if (h.frameId > maxId) maxId = h.frameId
        }
        if (h.count != a.count || a.chunks[h.idx] != null) return
        a.chunks[h.idx] = buf.copyOfRange(Proto.HEADER, len)
        a.got++
        a.lastRx = now
        pump(now)
    }

    /** Hand frames to the decoder strictly in order; give up on a frame only after the buffer deadline. */
    private fun pump(now: Long) {
        val deadline = deadlineNs()
        while (frames.isNotEmpty()) {
            val e = frames.firstEntry()
            val id = e.key
            val a = e.value
            if (id < nextId) { frames.remove(id); continue }
            if (id == nextId) {
                if (a.got == a.count) { frames.remove(id); nextId = id + 1; deliver(a); continue }
                if (now - a.first > deadline) { frames.remove(id); nextId = id + 1; abandon(1); continue }
                break
            }
            if (now - a.first > deadline) { val miss = id - nextId; nextId = id; abandon(miss); continue }
            break
        }
    }

    private fun abandon(n: Int) {
        lostFrames.addAndGet(n)
        needKey = true
        requestKey()
    }

    private fun deliver(a: Asm) {
        if (a.key) needKey = false
        val dec = decoder
        if (needKey || dec == null) {
            resync.incrementAndGet()          // waiting for a keyframe: not network loss
            needKey = true
            requestKey(if (dec == null) 1000L else 150L)
            return
        }
        val cfg = if (a.key) curConfig else null   // SPS/PPS in front of every keyframe (scrcpy style)
        var total = cfg?.size ?: 0
        for (c in a.chunks) total += c!!.size
        val d = ByteArray(total)
        var o = 0
        if (cfg != null) { System.arraycopy(cfg, 0, d, 0, cfg.size); o = cfg.size }
        for (c in a.chunks) { System.arraycopy(c!!, 0, d, o, c.size); o += c.size }
        try {
            val i = dec.dequeueInputBuffer(3000)
            if (i < 0) { dropped.incrementAndGet(); lostFrames.incrementAndGet(); needKey = true; requestKey(); return }
            dec.getInputBuffer(i)!!.apply { clear(); put(d) }
            if (arrivals.size > 64) arrivals.clear()
            arrivals[a.ts] = System.nanoTime()
            dec.queueInputBuffer(i, 0, total, a.ts, 0)
            okFrames.incrementAndGet()
        } catch (e: IllegalStateException) {
            Diag.log("decoder input error: $e")
            restartDecoder = true
        } catch (t: Throwable) {
            Diag.log("deliver: $t")
        }
    }

    private fun nackGapNs(): Long = (rttMs * 1_500_000f).toLong().coerceIn(6_000_000L, 25_000_000L)

    /** Re-request missing packets of incomplete frames (and whole frames that never showed up). */
    private fun housekeeping() {
        if (restartDecoder) {
            restartDecoder = false
            val m = decMime
            if (m != null) { startDecoder(m, vidW, vidH); needKey = true }
        }
        if (decoder == null && senderAddr != null) requestKey(1000L)   // phone is there but video isn't set up yet
        val now = System.nanoTime()
        pump(now)
        if (frames.isEmpty()) return
        val list = ArrayList<Pair<Int, Int>>()
        for (a in frames.values) {
            if (a.got == a.count) continue
            if (now - a.first < REORDER_NS) continue
            if (now - a.lastRx <= REORDER_NS && a.id >= maxId) continue      // still arriving
            if (now - a.lastNack < nackGapNs() || a.nacks >= 4) continue
            a.lastNack = now; a.nacks++
            for (i in 0 until a.count) {
                if (a.chunks[i] == null) { list.add(Pair(a.id, i)); if (list.size >= 60) break }
            }
            if (list.size >= 60) break
        }
        if (gapFor != nextId) { gapFor = nextId; gapTries = 0 }
        val first = frames.firstEntry()
        if (first != null && first.key > nextId && now - first.value.first > REORDER_NS &&
            now - gapNackAt > nackGapNs() && gapTries < 3
        ) {
            gapNackAt = now; gapTries++
            list.add(Pair(nextId, Proto.WHOLE_FRAME))
        }
        if (list.isNotEmpty()) sendNack(list)
    }

    @Synchronized
    private fun sendNack(list: List<Pair<Int, Int>>) {
        val addr = senderAddr ?: return
        val out = ByteArray(Proto.HEADER + list.size * 6)
        val b = ByteBuffer.wrap(out)
        Proto.write(b, Proto.T_NACK, 0, 0, 0, list.size, 0L)
        for ((f, i) in list) { b.putInt(f); b.putShort(i.toShort()) }
        try { socket?.send(DatagramPacket(out, out.size, addr)) } catch (_: Exception) {}
        nackPkts.addAndGet(list.size)
    }

    private fun outLoop(c: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        while (running && decoder === c) {
            try {
                val i = c.dequeueOutputBuffer(info, 5000)
                if (i < 0) continue
                arrivals.remove(info.presentationTimeUs)?.let {
                    decMs = decMs * 0.9f + (System.nanoTime() - it) / 1e6f * 0.1f
                }
                c.releaseOutputBuffer(i, true)   // render immediately, no vsync scheduling
                rendered.incrementAndGet()
            } catch (e: IllegalStateException) {
                if (decoder === c && running) { Diag.log("decoder output error: $e"); restartDecoder = true }
                break
            } catch (t: Throwable) {
                Diag.log("decoder out: $t")
                break
            }
        }
    }

    private fun requestKey(minGapMs: Long = 150L) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastReq < minGapMs) return
        lastReq = now
        sendCtl(Proto.T_REQ_KEY, 0L, 0, 0)
    }

    @Synchronized
    private fun sendCtl(type: Int, ts: Long, a: Int, b: Int) {
        val addr = senderAddr ?: return
        Proto.write(ctlBuf, type, 0, 0, 0, 1, ts)
        ctlBuf.putInt(a); ctlBuf.putInt(b)
        try { socket?.send(DatagramPacket(ctl, ctl.size, addr)) } catch (_: Exception) {}
    }

    private fun statsLoop() {
        var tick = 0
        while (running) {
            try { Thread.sleep(500) } catch (_: InterruptedException) { break }
            try {
                sendCtl(Proto.T_PING, System.nanoTime() / 1000, 0, 0)
                if (++tick % 2 != 0) continue
                val ok = okFrames.getAndSet(0); val lost = lostFrames.getAndSet(0)
                val by = bytes.getAndSet(0); val r = rendered.getAndSet(0)
                val dr = dropped.getAndSet(0); val nk = nackPkts.getAndSet(0); val rs = resync.getAndSet(0)
                sendCtl(Proto.T_STATS, 0L, ok, lost)
                val lossPct = if (ok + lost > 0) lost * 100f / (ok + lost) else 0f
                val dp = dataPkts.getAndSet(0)
                ui.onStats(Stats(vidW, vidH, r, (by * 8 / 1e6).toFloat(), lossPct, rttMs, decMs, nk, dr, rs,
                    dp, senderAddr?.toString()?.trimStart('/')?.substringBefore(':') ?: ""))
            } catch (t: Throwable) {
                Diag.log("stats: $t")
            }
        }
    }
}
