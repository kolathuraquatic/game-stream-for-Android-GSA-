package com.mirrorlink

import android.content.Context
import android.media.MediaCodec
import android.media.MediaFormat
import android.net.wifi.WifiManager
import android.os.Process
import android.os.SystemClock
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.SocketAddress
import java.net.SocketTimeoutException
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * TV side: UDP -> frame reassembly -> hardware decoder -> Surface, with zero buffering.
 * Any loss => drop until next IDR and ask the sender for one (no visual corruption).
 */
class Receiver(
    private val ctx: Context,
    private val surface: android.view.Surface,
    private val onSize: (Int, Int) -> Unit,
    private val onStats: (String) -> Unit
) {
    @Volatile private var running = false
    private var socket: DatagramSocket? = null
    @Volatile private var decoder: MediaCodec? = null
    private var curConfig: ByteArray? = null
    @Volatile private var senderAddr: SocketAddress? = null
    private var wifiLock: WifiManager.WifiLock? = null

    // frame assembly (rx thread only)
    private var asmId = -1
    private var asmCount = 0
    private var asmGot = 0
    private var asmKey = false
    private var asmTs = 0L
    private var chunks: Array<ByteArray?> = arrayOfNulls(0)
    private var lastDelivered = -1
    private var needKey = true
    private var lastReq = 0L

    // stats
    private val okFrames = AtomicInteger()
    private val lostFrames = AtomicInteger()
    private val bytes = AtomicLong()
    private val rendered = AtomicInteger()
    private val dropped = AtomicInteger()
    @Volatile private var rttMs = 0f
    @Volatile private var decMs = 0f
    private val arrivals = ConcurrentHashMap<Long, Long>()

    private val ctl = ByteArray(Proto.HEADER + 8)
    private val ctlBuf = ByteBuffer.wrap(ctl)

    fun start() {
        running = true
        socket = DatagramSocket(null).apply {
            reuseAddress = true
            receiveBufferSize = 4 shl 20
            trafficClass = 0xB8
            soTimeout = 500
            bind(InetSocketAddress(Proto.PORT))
        }
        wifiLock = (ctx.getSystemService(Context.WIFI_SERVICE) as WifiManager)
            .createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "mirror-rx").also { it.acquire() }
        Thread({ Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY); rxLoop() }, "mirror-rx").start()
        Thread(::statsLoop, "mirror-stats").start()
    }

    fun stop() {
        running = false
        try { socket?.close() } catch (_: Exception) {}
        try { decoder?.stop(); decoder?.release() } catch (_: Exception) {}
        decoder = null
        try { wifiLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
    }

    private fun rxLoop() {
        val buf = ByteArray(2048)
        val p = DatagramPacket(buf, buf.size)
        while (running) {
            p.length = buf.size
            try { socket!!.receive(p) }
            catch (e: SocketTimeoutException) { continue }
            catch (e: Exception) { break }
            val h = parseHeader(buf, p.length) ?: continue
            bytes.addAndGet(p.length.toLong())
            if (senderAddr == null) senderAddr = p.socketAddress
            when (h.type) {
                Proto.T_CONFIG -> { senderAddr = p.socketAddress; onConfig(buf, p.length) }
                Proto.T_VIDEO -> onVideo(h, buf, p.length)
                Proto.T_PONG -> rttMs = (System.nanoTime() / 1000 - h.ts) / 1000f
            }
        }
    }

    private fun onConfig(buf: ByteArray, len: Int) {
        val b = ByteBuffer.wrap(buf, Proto.HEADER, len - Proto.HEADER)
        val codecId = b.get().toInt()
        val w = b.short.toInt() and 0xFFFF
        val h = b.short.toInt() and 0xFFFF
        val csd = ByteArray(b.remaining()); b.get(csd)
        if (decoder != null && curConfig?.contentEquals(csd) == true) return
        curConfig = csd
        startDecoder(if (codecId == 1) MediaFormat.MIMETYPE_VIDEO_HEVC else MediaFormat.MIMETYPE_VIDEO_AVC, w, h, csd)
        needKey = true   // the IDR follows this config
        onSize(w, h)
    }

    private fun startDecoder(mime: String, w: Int, h: Int, csd: ByteArray) {
        val old = decoder
        decoder = null
        try { old?.stop(); old?.release() } catch (_: Exception) {}
        val f = MediaFormat.createVideoFormat(mime, w, h).apply {
            setInteger("low-latency", 1)
            setInteger(MediaFormat.KEY_PRIORITY, 0)
            setInteger(MediaFormat.KEY_OPERATING_RATE, 120)
        }
        val c = MediaCodec.createDecoderByType(mime)
        c.configure(f, surface, null, 0)
        c.start()
        val i = c.dequeueInputBuffer(100_000)
        if (i >= 0) {
            c.getInputBuffer(i)!!.apply { clear(); put(csd) }
            c.queueInputBuffer(i, 0, csd.size, 0, MediaCodec.BUFFER_FLAG_CODEC_CONFIG)
        }
        decoder = c
        Thread({ outLoop(c) }, "mirror-dec").start()
    }

    private fun onVideo(h: Header, buf: ByteArray, len: Int) {
        if (h.frameId < asmId && asmId - h.frameId < 1_000_000) return  // late packet of an old frame
        if (h.frameId != asmId) {
            if (asmId >= 0 && asmGot < asmCount) { needKey = true; requestKey() } // previous frame incomplete
            asmId = h.frameId; asmCount = h.count; asmGot = 0
            asmKey = h.flags and Proto.F_KEY != 0; asmTs = h.ts
            chunks = arrayOfNulls(h.count)
        }
        if (h.idx >= asmCount || chunks[h.idx] != null) return
        chunks[h.idx] = buf.copyOfRange(Proto.HEADER, len)
        if (++asmGot == asmCount) completeFrame()
    }

    private fun completeFrame() {
        val gap = asmId - lastDelivered - 1
        if (lastDelivered >= 0 && gap > 0) {
            lostFrames.addAndGet(gap)
            if (!asmKey) needKey = true
        }
        lastDelivered = asmId
        if (asmKey) needKey = false
        else if (needKey) { requestKey(); return }

        var total = 0
        for (c in chunks) total += c!!.size
        val d = ByteArray(total)
        var o = 0
        for (c in chunks) { System.arraycopy(c!!, 0, d, o, c.size); o += c.size }

        val dec = decoder ?: return
        try {
            val i = dec.dequeueInputBuffer(2000)
            if (i < 0) { dropped.incrementAndGet(); needKey = true; requestKey(); return }
            dec.getInputBuffer(i)!!.apply { clear(); put(d) }
            if (arrivals.size > 64) arrivals.clear()
            arrivals[asmTs] = System.nanoTime()
            dec.queueInputBuffer(i, 0, total, asmTs, 0)
            okFrames.incrementAndGet()
        } catch (_: Exception) {}
    }

    private fun outLoop(c: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        try {
            while (running && decoder === c) {
                val i = c.dequeueOutputBuffer(info, 5000)
                if (i < 0) continue
                arrivals.remove(info.presentationTimeUs)?.let {
                    decMs = decMs * 0.9f + (System.nanoTime() - it) / 1e6f * 0.1f
                }
                c.releaseOutputBuffer(i, true)   // render immediately, no vsync scheduling
                rendered.incrementAndGet()
            }
        } catch (_: Exception) {}
    }

    private fun requestKey() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastReq < 150) return
        lastReq = now
        sendCtl(Proto.T_REQ_KEY, 0L, 0, 0)
    }

    @Synchronized
    private fun sendCtl(type: Int, ts: Long, a: Int, b: Int) {
        val addr = senderAddr ?: return
        Proto.write(ctlBuf, type, 0, 0, 0, 1, ts)
        ctlBuf.putInt(a); ctlBuf.putInt(b)
        try { socket?.send(DatagramPacket(ctl, ctl.size, addr)) } catch (_: Exception) {}
    }

    private fun statsLoop() {
        var tick = 0
        while (running) {
            try { Thread.sleep(500) } catch (_: InterruptedException) { break }
            sendCtl(Proto.T_PING, System.nanoTime() / 1000, 0, 0)
            if (++tick % 2 != 0) continue
            val ok = okFrames.getAndSet(0); val lost = lostFrames.getAndSet(0)
            val by = bytes.getAndSet(0); val r = rendered.getAndSet(0); val dr = dropped.getAndSet(0)
            sendCtl(Proto.T_STATS, 0L, ok, lost)
            val lossPct = if (ok + lost > 0) lost * 100f / (ok + lost) else 0f
            onStats(
                "%d fps   %.1f Mbps   loss %.1f%%   rtt %.1f ms   decode %.1f ms   drops %d"
                    .format(r, by * 8 / 1e6, lossPct, rttMs, decMs, dr)
            )
        }
    }
}
