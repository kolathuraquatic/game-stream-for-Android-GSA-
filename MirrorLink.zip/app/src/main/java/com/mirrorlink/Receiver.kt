package com.mirrorlink

import android.content.Context
import android.media.MediaCodec
import android.media.MediaFormat
import android.net.wifi.WifiManager
import android.os.Process
import android.os.SystemClock
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.SocketAddress
import java.net.SocketTimeoutException
import java.nio.ByteBuffer
import java.util.TreeMap
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * TV side. UDP -> in-order reassembly window with NACK retransmit -> hardware decoder -> Surface.
 * A missing packet is re-requested (a few ms on LAN) instead of dropping to the next IDR; only
 * if a frame can't be recovered within ~45 ms is it abandoned and a new IDR requested.
 */
class Receiver(
    private val ctx: Context,
    private val surface: android.view.Surface,
    private val onSize: (Int, Int) -> Unit,
    private val onStats: (String) -> Unit
) {
    private class Asm(val id: Int, val count: Int, val key: Boolean, val ts: Long, val first: Long) {
        val chunks = arrayOfNulls<ByteArray>(count)
        var got = 0
        var maxIdx = -1
        var lastRx = first
        var lastNack = 0L
        var nacks = 0
    }

    private companion object {
        const val REORDER_NS = 2_000_000L
        const val DEADLINE_NS = 45_000_000L
    }

    @Volatile private var running = false
    private var socket: DatagramSocket? = null
    @Volatile private var decoder: MediaCodec? = null
    private var curConfig: ByteArray? = null
    @Volatile private var senderAddr: SocketAddress? = null
    private var wifiLock: WifiManager.WifiLock? = null

    // reassembly (rx thread only)
    private val frames = TreeMap<Int, Asm>()
    private var nextId = -1
    private var maxId = -1
    private var needKey = true
    private var lastReq = 0L
    private var gapFor = -1
    private var gapTries = 0
    private var gapNackAt = 0L

    // stats
    private val okFrames = AtomicInteger()
    private val lostFrames = AtomicInteger()
    private val bytes = AtomicLong()
    private val rendered = AtomicInteger()
    private val dropped = AtomicInteger()
    private val nackPkts = AtomicInteger()
    @Volatile private var rttMs = 0f
    @Volatile private var decMs = 0f
    @Volatile private var vidW = 0
    @Volatile private var vidH = 0
    @Volatile private var err = ""
    private val arrivals = ConcurrentHashMap<Long, Long>()

    private val ctl = ByteArray(Proto.HEADER + 8)
    private val ctlBuf = ByteBuffer.wrap(ctl)

    fun start() {
        running = true
        socket = DatagramSocket(null).apply {
            reuseAddress = true
            receiveBufferSize = 4 shl 20
            trafficClass = 0xB8
            soTimeout = 4
            bind(InetSocketAddress(Proto.PORT))
        }
        wifiLock = (ctx.getSystemService(Context.WIFI_SERVICE) as WifiManager)
            .createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "mirror-rx").also { it.acquire() }
        Thread({ Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY); rxLoop() }, "mirror-rx").start()
        Thread(::statsLoop, "mirror-stats").start()
    }

    fun stop() {
        running = false
        try { socket?.close() } catch (_: Exception) {}
        try { decoder?.stop(); decoder?.release() } catch (_: Exception) {}
        decoder = null
        try { wifiLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
    }

    private fun rxLoop() {
        val buf = ByteArray(2048)
        val p = DatagramPacket(buf, buf.size)
        var lastHk = 0L
        while (running) {
            p.length = buf.size
            try { socket!!.receive(p) }
            catch (e: SocketTimeoutException) { housekeeping(); continue }
            catch (e: Exception) { break }
            val h = parseHeader(buf, p.length) ?: continue
            bytes.addAndGet(p.length.toLong())
            if (senderAddr == null) senderAddr = p.socketAddress
            when (h.type) {
                Proto.T_CONFIG -> { senderAddr = p.socketAddress; onConfig(buf, p.length) }
                Proto.T_VIDEO -> onVideo(h, buf, p.length)
                Proto.T_PONG -> rttMs = (System.nanoTime() / 1000 - h.ts) / 1000f
            }
            val now = System.nanoTime()
            if (now - lastHk > 2_000_000L) { lastHk = now; housekeeping() }
        }
    }

    private fun onConfig(buf: ByteArray, len: Int) {
        val b = ByteBuffer.wrap(buf, Proto.HEADER, len - Proto.HEADER)
        val codecId = b.get().toInt()
        val w = b.short.toInt() and 0xFFFF
        val h = b.short.toInt() and 0xFFFF
        val csd = ByteArray(b.remaining()); b.get(csd)
        if (decoder != null && curConfig?.contentEquals(csd) == true) return
        curConfig = csd
        startDecoder(if (codecId == 1) MediaFormat.MIMETYPE_VIDEO_HEVC else MediaFormat.MIMETYPE_VIDEO_AVC, w, h, csd)
        needKey = true   // the IDR follows this config
        vidW = w; vidH = h
        onSize(w, h)
    }

    private fun startDecoder(mime: String, w: Int, h: Int, csd: ByteArray) {
        val old = decoder
        decoder = null
        try { old?.stop(); old?.release() } catch (_: Exception) {}
        try {
            val f = MediaFormat.createVideoFormat(mime, w, h).apply {
                setInteger("low-latency", 1)
                setInteger(MediaFormat.KEY_PRIORITY, 0)
                setInteger(MediaFormat.KEY_OPERATING_RATE, 120)
            }
            val c = MediaCodec.createDecoderByType(mime)
            c.configure(f, surface, null, 0)
            c.start()
            val i = c.dequeueInputBuffer(100_000)
            if (i >= 0) {
                c.getInputBuffer(i)!!.apply { clear(); put(csd) }
                c.queueInputBuffer(i, 0, csd.size, 0, MediaCodec.BUFFER_FLAG_CODEC_CONFIG)
            }
            decoder = c
            err = ""
            Thread({ outLoop(c) }, "mirror-dec").start()
        } catch (e: Exception) {
            err = "decoder ${w}x$h failed: ${e.message}"
        }
    }

    private fun onVideo(h: Header, buf: ByteArray, len: Int) {
        val now = System.nanoTime()
        if (nextId < 0) nextId = h.frameId
        if (h.frameId < nextId || h.count == 0 || h.idx >= h.count) return
        if (frames.size > 64) { frames.clear(); nextId = h.frameId; needKey = true; requestKey() }
        var a = frames[h.frameId]
        if (a == null) {
            a = Asm(h.frameId, h.count, h.flags and Proto.F_KEY != 0, h.ts, now)
            frames[h.frameId] = a
            if (h.frameId > maxId) maxId = h.frameId
        }
        if (h.count != a.count || a.chunks[h.idx] != null) return
        a.chunks[h.idx] = buf.copyOfRange(Proto.HEADER, len)
        a.got++
        a.lastRx = now
        if (h.idx > a.maxIdx) a.maxIdx = h.idx
        pump(now)
    }

    /** Hand frames to the decoder strictly in order; give up on a frame only after DEADLINE_NS. */
    private fun pump(now: Long) {
        while (frames.isNotEmpty()) {
            val e = frames.firstEntry()
            val id = e.key
            val a = e.value
            if (id < nextId) { frames.remove(id); continue }
            if (id == nextId) {
                if (a.got == a.count) { frames.remove(id); nextId = id + 1; deliver(a); continue }
                if (now - a.first > DEADLINE_NS) { frames.remove(id); nextId = id + 1; abandon(1); continue }
                break
            }
            if (now - a.first > DEADLINE_NS) { val miss = id - nextId; nextId = id; abandon(miss); continue }
            break
        }
    }

    private fun abandon(n: Int) {
        lostFrames.addAndGet(n)
        needKey = true
        requestKey()
    }

    private fun deliver(a: Asm) {
        if (a.key) needKey = false
        val dec = decoder
        if (needKey || dec == null) {
            lostFrames.incrementAndGet()
            needKey = true
            requestKey()
            return
        }
        var total = 0
        for (c in a.chunks) total += c!!.size
        val d = ByteArray(total)
        var o = 0
        for (c in a.chunks) { System.arraycopy(c!!, 0, d, o, c.size); o += c.size }
        try {
            val i = dec.dequeueInputBuffer(3000)
            if (i < 0) { dropped.incrementAndGet(); lostFrames.incrementAndGet(); needKey = true; requestKey(); return }
            dec.getInputBuffer(i)!!.apply { clear(); put(d) }
            if (arrivals.size > 64) arrivals.clear()
            arrivals[a.ts] = System.nanoTime()
            dec.queueInputBuffer(i, 0, total, a.ts, 0)
            okFrames.incrementAndGet()
        } catch (_: Exception) {}
    }

    private fun nackGapNs(): Long = (rttMs * 1_500_000f).toLong().coerceIn(6_000_000L, 25_000_000L)

    /** Re-request missing packets of incomplete frames (and whole frames that never showed up). */
    private fun housekeeping() {
        val now = System.nanoTime()
        pump(now)
        if (frames.isEmpty()) return
        val list = ArrayList<Pair<Int, Int>>()
        for (a in frames.values) {
            if (a.got == a.count) continue
            if (now - a.first < REORDER_NS) continue
            val moving = now - a.lastRx <= REORDER_NS && a.id >= maxId
            if (moving) continue
            if (now - a.lastNack < nackGapNs() || a.nacks >= 4) continue
            a.lastNack = now; a.nacks++
            for (i in 0 until a.count) {
                if (a.chunks[i] == null) { list.add(Pair(a.id, i)); if (list.size >= 60) break }
            }
            if (list.size >= 60) break
        }
        if (gapFor != nextId) { gapFor = nextId; gapTries = 0 }
        val first = frames.firstEntry()
        if (first != null && first.key > nextId && now - first.value.first > REORDER_NS &&
            now - gapNackAt > nackGapNs() && gapTries < 3
        ) {
            gapNackAt = now; gapTries++
            list.add(Pair(nextId, Proto.WHOLE_FRAME))
        }
        if (list.isNotEmpty()) sendNack(list)
    }

    @Synchronized
    private fun sendNack(list: List<Pair<Int, Int>>) {
        val addr = senderAddr ?: return
        val out = ByteArray(Proto.HEADER + list.size * 6)
        val b = ByteBuffer.wrap(out)
        Proto.write(b, Proto.T_NACK, 0, 0, 0, list.size, 0L)
        for ((f, i) in list) { b.putInt(f); b.putShort(i.toShort()) }
        try { socket?.send(DatagramPacket(out, out.size, addr)) } catch (_: Exception) {}
        nackPkts.addAndGet(list.size)
    }

    private fun outLoop(c: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        try {
            while (running && decoder === c) {
                val i = c.dequeueOutputBuffer(info, 5000)
                if (i < 0) continue
                arrivals.remove(info.presentationTimeUs)?.let {
                    decMs = decMs * 0.9f + (System.nanoTime() - it) / 1e6f * 0.1f
                }
                c.releaseOutputBuffer(i, true)   // render immediately, no vsync scheduling
                rendered.incrementAndGet()
            }
        } catch (_: Exception) {}
    }

    private fun requestKey() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastReq < 150) return
        lastReq = now
        sendCtl(Proto.T_REQ_KEY, 0L, 0, 0)
    }

    @Synchronized
    private fun sendCtl(type: Int, ts: Long, a: Int, b: Int) {
        val addr = senderAddr ?: return
        Proto.write(ctlBuf, type, 0, 0, 0, 1, ts)
        ctlBuf.putInt(a); ctlBuf.putInt(b)
        try { socket?.send(DatagramPacket(ctl, ctl.size, addr)) } catch (_: Exception) {}
    }

    private fun statsLoop() {
        var tick = 0
        while (running) {
            try { Thread.sleep(500) } catch (_: InterruptedException) { break }
            sendCtl(Proto.T_PING, System.nanoTime() / 1000, 0, 0)
            if (++tick % 2 != 0) continue
            val ok = okFrames.getAndSet(0); val lost = lostFrames.getAndSet(0)
            val by = bytes.getAndSet(0); val r = rendered.getAndSet(0)
            val dr = dropped.getAndSet(0); val nk = nackPkts.getAndSet(0)
            sendCtl(Proto.T_STATS, 0L, ok, lost)
            val lossPct = if (ok + lost > 0) lost * 100f / (ok + lost) else 0f
            val line = "%dx%d  %d fps  %.1f Mbps  loss %.1f%%  rtt %.1f ms  decode %.1f ms  nack %d  drops %d"
                .format(vidW, vidH, r, by * 8 / 1e6, lossPct, rttMs, decMs, nk, dr)
            onStats(if (err.isEmpty()) line else "$line\n$err")
        }
    }
}
