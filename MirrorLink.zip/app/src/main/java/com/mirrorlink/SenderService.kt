package com.mirrorlink

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Point
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.*
import android.util.Log
import android.view.Display
import android.view.Surface
import android.widget.Toast
import java.net.*
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.locks.LockSupport
import kotlin.math.max
import kotlin.math.min

/**
 * Phone side. MediaProjection -> VirtualDisplay -> hardware encoder (surface input) -> UDP.
 * v0.3: encoder "format ladder" (falls back until the phone accepts a format), staged error
 * messages + log, user settings, safer loops, rotation restart that re-runs the ladder.
 */
@Suppress("DEPRECATION")
class SenderService : Service() {
    companion object {
        const val ACTION_STOP = "stop"
        @Volatile var active = false
    }

    private class SentFrame(val type: Int, val flags: Int, val ts: Long, val data: ByteArray, val payload: Int)

    private var st = StreamSettings()
    private var projection: MediaProjection? = null
    private var vdisplay: VirtualDisplay? = null
    @Volatile private var codec: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var socket: DatagramSocket? = null
    private var target: InetSocketAddress? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var stopped = false

    private var mime = MediaFormat.MIMETYPE_VIDEO_AVC
    private var fpsUsed = 60
    private var maxBitrate = 20_000_000
    private var minBitrate = 8_000_000
    @Volatile private var bitrate = 20_000_000
    private var payload = Proto.PAYLOAD_WIFI
    private var curW = 0
    private var curH = 0
    private var lastBase = Pair(0, 0)
    private var encLevel = 0
    @Volatile private var config: ByteArray? = null
    private var frameId = 0
    private var lastKeyReq = 0L
    private var goodSeconds = 0
    @Volatile private var lastReplyAt = 0L
    private var startedAt = 0L
    private var warned = false
    private var statusKnown = false
    private var statusConnected = false

    private val pkt = ByteArray(Proto.HEADER + Proto.PAYLOAD_WIRED)
    private val bb = ByteBuffer.wrap(pkt)
    private var dp: DatagramPacket? = null

    private val sent = ConcurrentHashMap<Int, SentFrame>()
    private val rbuf = ByteArray(Proto.HEADER + Proto.PAYLOAD_WIRED)
    private val rbb = ByteBuffer.wrap(rbuf)
    private val rlock = Any()
    private val pktsSent = AtomicInteger()
    private val retrans = AtomicInteger()

    override fun onBind(i: Intent?): IBinder? = null
    override fun onDestroy() { stopAll() }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i == null || i.action == ACTION_STOP) return stopAll()
        if (running) return START_NOT_STICKY
        stopped = false
        createChannel()
        startForeground(1, buildNotification("Starting…"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        st = StreamSettings.from(i)
        maxBitrate = st.mbps * 1_000_000
        bitrate = maxBitrate
        minBitrate = max(3_000_000, (maxBitrate * 0.4f).toInt())
        var stage = "setup"
        try {
            stage = "network"
            if (st.host.isEmpty()) throw IllegalStateException("No receiver IP entered")
            val addr = InetSocketAddress(st.host, Proto.PORT)
            if (addr.isUnresolved) throw IllegalStateException("'${st.host}' is not a valid address - use the TV's IP")
            target = addr
            val s = DatagramSocket()
            try { s.sendBufferSize = 2 shl 20; s.trafficClass = 0xB8 } catch (_: Exception) {}
            s.soTimeout = 500
            socket = s
            val bound = bindNetwork(s, st.net, addr.address)
            payload = if (st.net == 2 || Net.isEthernet(this, bound)) Proto.PAYLOAD_WIRED else Proto.PAYLOAD_WIFI
            dp = DatagramPacket(pkt, pkt.size, addr)
            try {
                wifiLock = (applicationContext.getSystemService(WIFI_SERVICE) as WifiManager)
                    .createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "mirror-tx").also { it.acquire() }
            } catch (_: Throwable) {}

            stage = "screen capture permission"
            val data = i.getParcelableExtra<Intent>("data")
                ?: throw IllegalStateException("capture permission data missing - try again")
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val p = mpm.getMediaProjection(i.getIntExtra("code", 0), data)
                ?: throw IllegalStateException("Android refused the capture session")
            projection = p
            p.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopAll() } }, handler)

            running = true
            stage = "video encoder"
            val base = baseSize()
            lastBase = base
            startEncoderLadder(base.first, base.second)

            stage = "virtual display"
            vdisplay = p.createVirtualDisplay(
                "mirror", curW, curH, resources.displayMetrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, inputSurface, null, null
            ) ?: throw IllegalStateException("could not create the capture display")

            stage = "feedback channel"
            getSystemService(DisplayManager::class.java).registerDisplayListener(displayListener, handler)
            Thread(::feedbackLoop, "mirror-fb").start()
            active = true
            startedAt = SystemClock.elapsedRealtime(); lastReplyAt = 0L; warned = false; statusKnown = false
            handler.postDelayed(statusRunnable, 1000)
            val info = "${if (mime == MediaFormat.MIMETYPE_VIDEO_HEVC) "HEVC" else "H.264"} ${curW}x$curH " +
                "${fpsUsed}fps ${st.mbps}Mbps (encoder level $encLevel, ${if (payload == Proto.PAYLOAD_WIRED) "wired" else "Wi-Fi"} packets)"
            Diag.log("streaming to ${st.host}: $info")
            toast("Streaming: $info")
        } catch (e: Throwable) {
            val msg = "$stage: ${e.javaClass.simpleName}${e.message?.let { ": $it" } ?: ""}"
            Diag.log("START FAILED $msg\n" + Log.getStackTraceString(e))
            toast("Could not start - $msg")
            return stopAll()
        }
        return START_NOT_STICKY
    }

    // ---------- network ----------
    /**
     * Pins the socket to the Wi-Fi/Ethernet network that can reach the TV. Without this Android may
     * send local traffic over mobile data (when Wi-Fi has no internet) and the TV never receives it.
     */
    private fun bindNetwork(s: DatagramSocket, mode: Int, dest: InetAddress): android.net.Network? {
        val net = Net.bestNetwork(this, dest, mode)
        if (net == null) {
            if (mode == 2) throw IllegalStateException("no Ethernet link on this phone (needs a USB-C Ethernet adapter)")
            if (mode == 1) throw IllegalStateException("Wi-Fi is not connected")
            Diag.log("no Wi-Fi/Ethernet network found; using Android's default route")
            return null
        }
        net.bindSocket(s)
        Diag.log("socket bound to ${Net.describe(this, net)}")
        return net
    }

    // ---------- sizing ----------
    /** Full screen at the right aspect, never bigger than the 16:9 box (decoder-safe), before codec alignment. */
    private fun baseSize(): Pair<Int, Int> {
        val d = getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
        val p = Point(); d.getRealSize(p)
        var w = p.x; var h = p.y
        if (st.orient == 1 && h > w) { val t = w; w = h; h = t }
        if (st.orient == 2 && w > h) { val t = w; w = h; h = t }
        val boxShort = st.edge * 9 / 16
        val s = minOf(1f, st.edge.toFloat() / w, boxShort.toFloat() / h)
        return Pair((w * s).toInt(), (h * s).toInt())
    }

    private fun alignFor(info: MediaCodecInfo, m: String, w0: Int, h0: Int): Pair<Int, Int> {
        val vc = try { info.getCapabilitiesForType(m).videoCapabilities } catch (_: Throwable) { null }
        val aw = max(16, vc?.widthAlignment ?: 2)
        val ah = max(16, vc?.heightAlignment ?: 2)
        var fw = max(aw, w0 / aw * aw)
        var fh = max(ah, h0 / ah * ah)
        if (vc != null) {
            var tries = 0
            while (!vc.isSizeSupported(fw, fh) && tries++ < 12) {
                fw = max(aw, (fw * 0.9f).toInt() / aw * aw)
                fh = max(ah, (fh * 0.9f).toInt() / ah * ah)
            }
        }
        return Pair(fw, fh)
    }

    // ---------- encoder ----------
    private fun encoderInfos(m: String): List<MediaCodecInfo> {
        val all = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
            .filter { it.isEncoder && it.supportedTypes.any { t -> t.equals(m, true) } }
        return all.filter { it.isHardwareAccelerated } + all.filter { !it.isHardwareAccelerated }
    }

    /**
     * Phones differ in which format keys they accept (a rejected key throws a message-less
     * IllegalArgumentException). Try: every encoder x full/75% size x 4 progressively simpler formats.
     */
    private fun startEncoderLadder(bw: Int, bh: Int) {
        val errors = ArrayList<String>()
        val mimes = if (st.hevc) listOf(MediaFormat.MIMETYPE_VIDEO_HEVC, MediaFormat.MIMETYPE_VIDEO_AVC)
        else listOf(MediaFormat.MIMETYPE_VIDEO_AVC)
        for (m in mimes) {
            for (info in encoderInfos(m)) {
                for (sc in floatArrayOf(1f, 0.75f)) {
                    val sz = alignFor(info, m, (bw * sc).toInt(), (bh * sc).toInt())
                    for (lvl in 0..3) {
                        try {
                            buildEncoder(info, m, sz.first, sz.second, lvl)
                            return
                        } catch (t: Throwable) {
                            errors.add("${info.name} ${sz.first}x${sz.second} L$lvl: ${t.javaClass.simpleName} ${t.message ?: ""}")
                        }
                    }
                }
            }
        }
        Diag.log("encoder ladder failed:\n" + errors.joinToString("\n"))
        throw IllegalStateException("no encoder accepted the video format (${errors.size} tries). Last: ${errors.lastOrNull() ?: "no encoder found"}")
    }

    private fun buildEncoder(info: MediaCodecInfo, m: String, w: Int, h: Int, lvl: Int) {
        val vc = try { info.getCapabilitiesForType(m).videoCapabilities } catch (_: Throwable) { null }
        val br = try { if (vc != null) bitrate.coerceIn(vc.bitrateRange.lower, vc.bitrateRange.upper) else bitrate } catch (_: Throwable) { bitrate }
        val maxFps = try { vc?.getSupportedFrameRatesFor(w, h)?.upper?.toInt() ?: st.fps } catch (_: Throwable) { st.fps }
        val fps = min(st.fps, max(15, maxFps))
        val c = MediaCodec.createByCodecName(info.name)
        try {
            val f = MediaFormat.createVideoFormat(m, w, h)
            f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            f.setInteger(MediaFormat.KEY_BIT_RATE, br)
            f.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, st.iframe)
            if (lvl <= 2) {
                f.setInteger(MediaFormat.KEY_BITRATE_MODE,
                    if (lvl == 2 || !st.cbr) MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR
                    else MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR)
                f.setInteger("prepend-sps-pps-to-idr-frames", 1)
            }
            if (lvl <= 1) f.setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 100_000L)
            if (lvl == 0) {
                f.setInteger(MediaFormat.KEY_PRIORITY, 0)
                f.setInteger(MediaFormat.KEY_OPERATING_RATE, fps)
                f.setInteger(MediaFormat.KEY_MAX_B_FRAMES, 0)
                f.setInteger("low-latency", 1)
                f.setInteger("latency", 1)
            }
            c.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val s = c.createInputSurface()
            c.start()
            mime = m; fpsUsed = fps; encLevel = lvl
            inputSurface = s; curW = w; curH = h; config = null
            codec = c
            Thread({ drain(c) }, "mirror-enc").also { it.priority = Thread.MAX_PRIORITY }.start()
        } catch (t: Throwable) {
            try { c.release() } catch (_: Throwable) {}
            throw t
        }
    }

    private fun drain(c: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        while (running && codec === c) {
            try {
                val i = c.dequeueOutputBuffer(info, 10_000)
                if (i < 0) continue
                val buf = c.getOutputBuffer(i)
                if (buf != null && info.size > 0) {
                    buf.position(info.offset); buf.limit(info.offset + info.size)
                    val data = ByteArray(info.size); buf.get(data)
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
                        config = data; sendConfig()
                    } else {
                        sendFrame(data, info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0, info.presentationTimeUs)
                    }
                }
                c.releaseOutputBuffer(i, false)
            } catch (e: IllegalStateException) {
                break
            } catch (t: Throwable) {
                Diag.log("encoder loop: $t")
            }
        }
    }

    // ---------- sending ----------
    private fun sendConfig() {
        val cfg = config ?: ByteArray(0)   // some encoders put SPS/PPS inline only: still tell the TV size + codec
        val b = ByteBuffer.allocate(Proto.CFG_HDR + cfg.size)
        b.put(if (mime == MediaFormat.MIMETYPE_VIDEO_HEVC) 1 else 0)
        b.putShort(curW.toShort()); b.putShort(curH.toShort())
        b.putShort(st.edge.toShort()); b.putShort((((st.edge * 9 / 16) + 15) / 16 * 16).toShort())
        b.put(st.scale.toByte()); b.put(st.buffer.toByte()); b.put((if (st.showStats) 1 else 0).toByte())
        b.put(cfg)
        emit(Proto.T_CONFIG, 0, 0, 0L, b.array(), payload, false)
    }

    private fun sendFrame(d: ByteArray, key: Boolean, ts: Long) {
        if (key) sendConfig()
        val fid = frameId++
        val flags = if (key) Proto.F_KEY else 0
        sent[fid] = SentFrame(Proto.T_VIDEO, flags, ts, d, payload)   // kept briefly for NACK retransmit
        sent.remove(fid - 24)
        emit(Proto.T_VIDEO, flags, fid, ts, d, payload, true)
    }

    private fun emit(type: Int, flags: Int, fid: Int, ts: Long, d: ByteArray, pay: Int, pace: Boolean) {
        val s = socket ?: return
        val count = (d.size + pay - 1) / pay
        // spread big frames (IDR) over ~70% of a frame interval instead of one burst
        val gapNs = if (pace && count > 8) 700_000_000L / fpsUsed / count else 0L
        var off = 0
        for (idx in 0 until count) {
            val len = min(pay, d.size - off)
            Proto.write(bb, type, flags, fid, idx, count, ts)
            bb.put(d, off, len)
            dp!!.setData(pkt, 0, Proto.HEADER + len)
            try { s.send(dp) } catch (e: Exception) { onSendError(e) }
            off += len
            if (gapNs > 0 && idx % 4 == 3) LockSupport.parkNanos(gapNs * 4)
        }
        pktsSent.addAndGet(count)
    }

    @Volatile private var sendErrors = 0

    private fun onSendError(e: Exception) {
        if (++sendErrors == 20) {
            Diag.log("UDP send keeps failing: $e")
            toast("Can't reach the TV (${e.message ?: e.javaClass.simpleName}). Check Wi-Fi / IP.")
        }
    }

    private fun retransmit(fid: Int, idx: Int) {
        val f = sent[fid] ?: return
        val s = socket ?: return
        val count = (f.data.size + f.payload - 1) / f.payload
        val range = if (idx == Proto.WHOLE_FRAME) 0 until count else if (idx < count) idx..idx else return
        synchronized(rlock) {
            for (i in range) {
                val off = i * f.payload
                val len = min(f.payload, f.data.size - off)
                Proto.write(rbb, f.type, f.flags, fid, i, count, f.ts)
                rbb.put(f.data, off, len)
                try { s.send(DatagramPacket(rbuf, Proto.HEADER + len, target)) } catch (_: Exception) {}
                retrans.incrementAndGet()
            }
        }
    }

    // ---------- feedback ----------
    private fun feedbackLoop() {
        val buf = ByteArray(1024)
        val rp = DatagramPacket(buf, buf.size)
        val out = ByteArray(Proto.HEADER)
        val ob = ByteBuffer.wrap(out)
        val hello = ByteArray(Proto.HEADER)
        val hb = ByteBuffer.wrap(hello)
        while (running) {
            rp.length = buf.size
            try { socket!!.receive(rp) }
            catch (e: SocketTimeoutException) {
                // nothing heard for 500 ms: say hello so the TV learns our address even if no video is flowing
                try {
                    Proto.write(hb, Proto.T_HELLO, Proto.HELLO_STREAM, 0, 0, 1, 0L)
                    socket?.send(DatagramPacket(hello, hello.size, target))
                } catch (_: Exception) {}
                continue
            }
            catch (e: Exception) { break }
            try {
                val h = parseHeader(buf, rp.length) ?: continue
                lastReplyAt = SystemClock.elapsedRealtime()
                when (h.type) {
                    Proto.T_PING -> {
                        Proto.write(ob, Proto.T_PONG, 0, 0, 0, 1, h.ts)
                        socket!!.send(DatagramPacket(out, out.size, rp.socketAddress))
                    }
                    Proto.T_REQ_KEY -> requestKey()
                    Proto.T_NACK -> {
                        val b = ByteBuffer.wrap(buf, Proto.HEADER, rp.length - Proto.HEADER)
                        var n = h.count
                        while (n-- > 0 && b.remaining() >= 6) {
                            val fid = b.int
                            val idx = b.short.toInt() and 0xFFFF
                            retransmit(fid, idx)
                        }
                    }
                    Proto.T_STATS -> if (rp.length >= Proto.HEADER + 8) onStats(ByteBuffer.wrap(buf, Proto.HEADER, 8))
                }
            } catch (t: Throwable) {
                Diag.log("feedback: $t")
            }
        }
    }

    private fun requestKey() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastKeyReq < 150) return
        lastKeyReq = now
        setParam(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0)
    }

    private fun setParam(key: String, v: Int) {
        try { codec?.setParameters(Bundle().apply { putInt(key, v) }) } catch (_: Throwable) {}
    }

    /** Optional adaptive bitrate: back off on real loss, creep up when clean; never below 40% of your setting. */
    private fun onStats(b: ByteBuffer) {
        val ok = b.int; val lost = b.int
        val sentN = pktsSent.getAndSet(0); val rt = retrans.getAndSet(0)
        if (!st.adaptive) return
        val rr = if (sentN > 0) rt * 100f / sentN else 0f
        val total = ok + lost
        val loss = if (total > 0) lost * 100f / total else 0f
        val raw = when {
            loss > 3f || rr > 10f -> { goodSeconds = 0; (bitrate * 0.85f).toInt() }
            loss < 0.5f && rr < 3f -> if (++goodSeconds >= 3) { goodSeconds = 0; bitrate + 1_000_000 } else bitrate
            else -> { goodSeconds = 0; bitrate }
        }
        val nr = raw.coerceIn(minBitrate, maxBitrate)
        if (nr != bitrate) { bitrate = nr; setParam(MediaCodec.PARAMETER_KEY_VIDEO_BITRATE, nr) }
    }

    // ---------- rotation (Auto mode only) ----------
    private val restartRunnable = Runnable { doRestart() }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(id: Int) {}
        override fun onDisplayRemoved(id: Int) {}
        override fun onDisplayChanged(id: Int) {
            if (id != Display.DEFAULT_DISPLAY || !running || st.orient != 0) return
            handler.removeCallbacks(restartRunnable)
            handler.postDelayed(restartRunnable, 300)     // let the rotation animation settle
        }
    }

    private fun doRestart() {
        if (!running) return
        try {
            val base = baseSize()
            if (base == lastBase) return
            val oldC = codec; val oldS = inputSurface
            codec = null                                   // stops the old drain thread
            try { vdisplay?.surface = null } catch (_: Throwable) {}
            try { oldC?.stop() } catch (_: Throwable) {}
            try { oldC?.release() } catch (_: Throwable) {}
            try { oldS?.release() } catch (_: Throwable) {}
            startEncoderLadder(base.first, base.second)     // old encoder is gone first: no concurrent-encoder limit
            vdisplay?.resize(curW, curH, resources.displayMetrics.densityDpi)
            vdisplay?.surface = inputSurface
            lastBase = base
            Diag.log("rotated -> ${curW}x$curH")
        } catch (t: Throwable) {
            Diag.log("rotation restart failed: $t\n" + Log.getStackTraceString(t))
            toast("Rotation failed: ${t.javaClass.simpleName} ${t.message ?: ""}")
            stopAll()
        }
    }

    // ---------- connection status ----------
    private fun buildNotification(text: String): Notification {
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, SenderService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, "mirror")
            .setContentTitle("MirrorLink")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(Notification.Action.Builder(0, "Stop", stopPi).build())
            .build()
    }

    private val statusRunnable = object : Runnable {
        override fun run() {
            if (!running) return
            val now = SystemClock.elapsedRealtime()
            val connected = lastReplyAt != 0L && now - lastReplyAt < 3000
            if (!statusKnown || connected != statusConnected) {
                statusKnown = true; statusConnected = connected
                val text = if (connected) "Streaming to ${st.host} - TV connected"
                else "Streaming to ${st.host} - waiting for the TV to answer…"
                try { getSystemService(NotificationManager::class.java).notify(1, buildNotification(text)) } catch (_: Throwable) {}
            }
            if (!connected && !warned && now - startedAt > 6000) {
                warned = true
                Diag.log("no reply from TV ${st.host} after 6 s")
                toast("The TV at ${st.host} is not answering. Check: TV app open on Receive, same Wi-Fi, IP typed exactly as the TV shows.")
            }
            handler.postDelayed(this, 1000)
        }
    }

    // ---------- misc ----------
    private fun toast(msg: String) {
        handler.post { try { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() } catch (_: Throwable) {} }
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("mirror", "Streaming", NotificationManager.IMPORTANCE_LOW))
    }

    private fun stopAll(): Int {
        if (stopped) return START_NOT_STICKY
        stopped = true
        running = false
        active = false
        handler.removeCallbacks(restartRunnable)
        handler.removeCallbacks(statusRunnable)
        try { getSystemService(DisplayManager::class.java).unregisterDisplayListener(displayListener) } catch (_: Throwable) {}
        try { codec?.stop(); codec?.release() } catch (_: Throwable) {}
        codec = null
        try { inputSurface?.release() } catch (_: Throwable) {}
        try { vdisplay?.release() } catch (_: Throwable) {}
        try { projection?.stop() } catch (_: Throwable) {}
        try { socket?.close() } catch (_: Throwable) {}
        try { wifiLock?.let { if (it.isHeld) it.release() } } catch (_: Throwable) {}
        sent.clear()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        return START_NOT_STICKY
    }
}
