package com.mirrorlink

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Point
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.*
import android.view.Display
import android.view.Surface
import android.widget.Toast
import java.net.*
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.locks.LockSupport
import kotlin.math.max
import kotlin.math.min

/**
 * Phone side. MediaProjection -> VirtualDisplay -> hardware encoder (surface input) -> UDP.
 * v0.2: aspect-correct sizing inside a 16:9 box (decoder-safe), orientation modes, safe rotation
 * restart, NACK retransmission, rate-paced frames, wired/Wi-Fi network binding.
 */
@Suppress("DEPRECATION")
class SenderService : Service() {
    companion object { const val ACTION_STOP = "stop" }

    private class SentFrame(val type: Int, val flags: Int, val ts: Long, val data: ByteArray, val payload: Int)

    private var projection: MediaProjection? = null
    private var vdisplay: VirtualDisplay? = null
    @Volatile private var codec: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var socket: DatagramSocket? = null
    private var target: InetSocketAddress? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var stopped = false

    private var mime = MediaFormat.MIMETYPE_VIDEO_AVC
    private var fps = 60
    private var maxEdge = 1920
    private var maxBitrate = 20_000_000
    @Volatile private var bitrate = 20_000_000
    private var orient = 0            // 0 auto, 1 landscape lock, 2 portrait lock
    private var payload = Proto.PAYLOAD_WIFI
    private var curW = 0
    private var curH = 0
    @Volatile private var config: ByteArray? = null
    private var frameId = 0
    private var lastKeyReq = 0L
    private var goodSeconds = 0

    private val pkt = ByteArray(Proto.HEADER + Proto.PAYLOAD_WIRED)
    private val bb = ByteBuffer.wrap(pkt)
    private var dp: DatagramPacket? = null

    private val sent = ConcurrentHashMap<Int, SentFrame>()
    private val rbuf = ByteArray(Proto.HEADER + Proto.PAYLOAD_WIRED)
    private val rbb = ByteBuffer.wrap(rbuf)
    private val rlock = Any()
    private val pktsSent = AtomicInteger()
    private val retrans = AtomicInteger()

    override fun onBind(i: Intent?): IBinder? = null
    override fun onDestroy() { stopAll() }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i == null || i.action == ACTION_STOP) return stopAll()
        stopped = false
        createChannel()
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, SenderService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "mirror")
            .setContentTitle("MirrorLink is streaming")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(Notification.Action.Builder(0, "Stop", stopPi).build())
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        mime = if (i.getBooleanExtra("hevc", false)) MediaFormat.MIMETYPE_VIDEO_HEVC else MediaFormat.MIMETYPE_VIDEO_AVC
        fps = i.getIntExtra("fps", 60)
        maxEdge = i.getIntExtra("edge", 1920)
        maxBitrate = i.getIntExtra("mbps", 20) * 1_000_000
        bitrate = maxBitrate
        orient = i.getIntExtra("orient", 0)
        val net = i.getIntExtra("net", 0)          // 0 auto, 1 Wi-Fi, 2 wired
        val host = i.getStringExtra("host") ?: return stopAll()

        try {
            target = InetSocketAddress(host, Proto.PORT)
            val s = DatagramSocket().apply { sendBufferSize = 2 shl 20; trafficClass = 0xB8; soTimeout = 500 }
            socket = s
            bindNetwork(s, net)
            payload = if (net == 2 || (net == 0 && ethernetActive())) Proto.PAYLOAD_WIRED else Proto.PAYLOAD_WIFI
            dp = DatagramPacket(pkt, pkt.size, target)
            wifiLock = (applicationContext.getSystemService(WIFI_SERVICE) as WifiManager)
                .createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "mirror-tx").also { it.acquire() }

            val mpm = getSystemService(MediaProjectionManager::class.java)
            val p = mpm.getMediaProjection(i.getIntExtra("code", 0), i.getParcelableExtra("data")!!)
            projection = p
            p.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopAll() } }, handler)

            running = true
            val (w, h) = computeSize()
            startEncoder(w, h, true)
            vdisplay = p.createVirtualDisplay(
                "mirror", w, h, resources.displayMetrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, inputSurface, null, null
            )
            getSystemService(DisplayManager::class.java).registerDisplayListener(displayListener, handler)
            Thread(::feedbackLoop, "mirror-fb").start()
        } catch (e: Exception) {
            toast("Could not start: ${e.message}")
            return stopAll()
        }
        return START_NOT_STICKY
    }

    // ---------- network ----------
    private fun ethernetActive(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java)
        val n = cm.activeNetwork ?: return false
        return cm.getNetworkCapabilities(n)?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true
    }

    private fun bindNetwork(s: DatagramSocket, mode: Int) {
        if (mode == 0) return
        val cm = getSystemService(ConnectivityManager::class.java)
        val want = if (mode == 2) NetworkCapabilities.TRANSPORT_ETHERNET else NetworkCapabilities.TRANSPORT_WIFI
        val net = cm.allNetworks.firstOrNull { cm.getNetworkCapabilities(it)?.hasTransport(want) == true }
            ?: throw IllegalStateException(
                if (mode == 2) "No Ethernet connection on this phone (plug in a USB-C Ethernet adapter)"
                else "Wi-Fi is not connected"
            )
        net.bindSocket(s)
    }

    // ---------- sizing ----------
    private fun pickEncoder(): MediaCodecInfo? {
        val all = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
            .filter { it.isEncoder && it.supportedTypes.any { t -> t.equals(mime, true) } }
        return all.firstOrNull { it.isHardwareAccelerated } ?: all.firstOrNull()
    }

    /** Full screen, correct aspect, never taller than the 16:9 box (so any TV decoder accepts it), codec-aligned. */
    private fun computeSize(): Pair<Int, Int> {
        val d = getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
        val p = Point(); d.getRealSize(p)
        var w = p.x; var h = p.y
        if (orient == 1 && h > w) { val t = w; w = h; h = t }
        if (orient == 2 && w > h) { val t = w; w = h; h = t }
        val boxShort = maxEdge * 9 / 16
        val s = minOf(1f, maxEdge.toFloat() / w, boxShort.toFloat() / h)
        var fw = (w * s).toInt()
        var fh = (h * s).toInt()
        val vc = try { pickEncoder()?.getCapabilitiesForType(mime)?.videoCapabilities } catch (_: Exception) { null }
        val aw = max(16, vc?.widthAlignment ?: 2)
        val ah = max(16, vc?.heightAlignment ?: 2)
        fw = max(aw, fw / aw * aw); fh = max(ah, fh / ah * ah)
        if (vc != null) {
            var tries = 0
            while (!vc.isSizeSupported(fw, fh) && tries++ < 12) {
                fw = max(aw, (fw * 0.9f).toInt() / aw * aw)
                fh = max(ah, (fh * 0.9f).toInt() / ah * ah)
            }
        }
        return Pair(fw, fh)
    }

    // ---------- encoder ----------
    private fun startEncoder(w: Int, h: Int, cbr: Boolean) {
        val info = pickEncoder()
        val c = if (info != null) MediaCodec.createByCodecName(info.name) else MediaCodec.createEncoderByType(mime)
        val f = MediaFormat.createVideoFormat(mime, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 4)
            setInteger(MediaFormat.KEY_BITRATE_MODE,
                if (cbr) MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR
                else MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
            setInteger(MediaFormat.KEY_PRIORITY, 0)
            setInteger(MediaFormat.KEY_OPERATING_RATE, fps)
            setInteger(MediaFormat.KEY_MAX_B_FRAMES, 0)
            setInteger("low-latency", 1)
            setInteger("latency", 1)
            setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 100_000L)
        }
        try {
            c.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        } catch (e: Exception) {
            c.release()
            if (cbr) { startEncoder(w, h, false); return } else throw e
        }
        val s = c.createInputSurface()
        c.start()
        inputSurface = s; curW = w; curH = h; config = null
        codec = c
        Thread({ drain(c) }, "mirror-enc").also { it.priority = Thread.MAX_PRIORITY }.start()
    }

    private fun drain(c: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        try {
            while (running && codec === c) {
                val i = c.dequeueOutputBuffer(info, 10_000)
                if (i < 0) continue
                val buf = c.getOutputBuffer(i)
                if (buf != null && info.size > 0) {
                    buf.position(info.offset); buf.limit(info.offset + info.size)
                    val data = ByteArray(info.size); buf.get(data)
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
                        config = data; sendConfig()
                    } else {
                        sendFrame(data, info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0, info.presentationTimeUs)
                    }
                }
                c.releaseOutputBuffer(i, false)
            }
        } catch (_: Exception) {}
    }

    // ---------- sending ----------
    private fun sendConfig() {
        val cfg = config ?: return
        val b = ByteBuffer.allocate(5 + cfg.size)
        b.put(if (mime == MediaFormat.MIMETYPE_VIDEO_HEVC) 1 else 0)
        b.putShort(curW.toShort()); b.putShort(curH.toShort()); b.put(cfg)
        emit(Proto.T_CONFIG, 0, 0, 0L, b.array(), payload, false)
    }

    private fun sendFrame(d: ByteArray, key: Boolean, ts: Long) {
        if (key) sendConfig()
        val fid = frameId++
        val flags = if (key) Proto.F_KEY else 0
        sent[fid] = SentFrame(Proto.T_VIDEO, flags, ts, d, payload)   // kept briefly for NACK retransmit
        sent.remove(fid - 24)
        emit(Proto.T_VIDEO, flags, fid, ts, d, payload, true)
    }

    private fun emit(type: Int, flags: Int, fid: Int, ts: Long, d: ByteArray, pay: Int, pace: Boolean) {
        val s = socket ?: return
        val count = (d.size + pay - 1) / pay
        // spread big frames (IDR) over ~70% of a frame interval instead of one burst
        val gapNs = if (pace && count > 8) 700_000_000L / fps / count else 0L
        var off = 0
        for (idx in 0 until count) {
            val len = min(pay, d.size - off)
            Proto.write(bb, type, flags, fid, idx, count, ts)
            bb.put(d, off, len)
            dp!!.setData(pkt, 0, Proto.HEADER + len)
            try { s.send(dp) } catch (_: Exception) {}
            off += len
            if (gapNs > 0 && idx % 4 == 3) LockSupport.parkNanos(gapNs * 4)
        }
        pktsSent.addAndGet(count)
    }

    private fun retransmit(fid: Int, idx: Int) {
        val f = sent[fid] ?: return
        val s = socket ?: return
        val count = (f.data.size + f.payload - 1) / f.payload
        val range = if (idx == Proto.WHOLE_FRAME) 0 until count else if (idx < count) idx..idx else return
        synchronized(rlock) {
            for (i in range) {
                val off = i * f.payload
                val len = min(f.payload, f.data.size - off)
                Proto.write(rbb, f.type, f.flags, fid, i, count, f.ts)
                rbb.put(f.data, off, len)
                try { s.send(DatagramPacket(rbuf, Proto.HEADER + len, target)) } catch (_: Exception) {}
                retrans.incrementAndGet()
            }
        }
    }

    // ---------- feedback ----------
    private fun feedbackLoop() {
        val buf = ByteArray(1024)
        val rp = DatagramPacket(buf, buf.size)
        val out = ByteArray(Proto.HEADER)
        val ob = ByteBuffer.wrap(out)
        while (running) {
            rp.length = buf.size
            try { socket!!.receive(rp) }
            catch (e: SocketTimeoutException) { continue }
            catch (e: Exception) { break }
            val h = parseHeader(buf, rp.length) ?: continue
            when (h.type) {
                Proto.T_PING -> {
                    Proto.write(ob, Proto.T_PONG, 0, 0, 0, 1, h.ts)
                    try { socket!!.send(DatagramPacket(out, out.size, rp.socketAddress)) } catch (_: Exception) {}
                }
                Proto.T_REQ_KEY -> requestKey()
                Proto.T_NACK -> {
                    val b = ByteBuffer.wrap(buf, Proto.HEADER, rp.length - Proto.HEADER)
                    var n = h.count
                    while (n-- > 0 && b.remaining() >= 6) {
                        val fid = b.int
                        val idx = b.short.toInt() and 0xFFFF
                        retransmit(fid, idx)
                    }
                }
                Proto.T_STATS -> onStats(ByteBuffer.wrap(buf, Proto.HEADER, 8))
            }
        }
    }

    private fun requestKey() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastKeyReq < 150) return
        lastKeyReq = now
        setParam(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0)
    }

    private fun setParam(key: String, v: Int) {
        try { codec?.setParameters(Bundle().apply { putInt(key, v) }) } catch (_: Exception) {}
    }

    /** Back off fast on loss or heavy retransmission, creep up when clean. */
    private fun onStats(b: ByteBuffer) {
        val ok = b.int; val lost = b.int
        val sentN = pktsSent.getAndSet(0); val rt = retrans.getAndSet(0)
        val rr = if (sentN > 0) rt * 100f / sentN else 0f
        val total = ok + lost
        val loss = if (total > 0) lost * 100f / total else 0f
        val raw = when {
            loss > 1.5f || rr > 4f -> { goodSeconds = 0; (bitrate * 0.8f).toInt() }
            loss < 0.3f && rr < 1f -> if (++goodSeconds >= 3) { goodSeconds = 0; bitrate + 1_000_000 } else bitrate
            else -> { goodSeconds = 0; bitrate }
        }
        val nr = raw.coerceIn(3_000_000, maxBitrate)
        if (nr != bitrate) { bitrate = nr; setParam(MediaCodec.PARAMETER_KEY_VIDEO_BITRATE, nr) }
    }

    // ---------- rotation (Auto mode only) ----------
    private val restartRunnable = Runnable { doRestart() }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(id: Int) {}
        override fun onDisplayRemoved(id: Int) {}
        override fun onDisplayChanged(id: Int) {
            if (id != Display.DEFAULT_DISPLAY || !running || orient != 0) return
            handler.removeCallbacks(restartRunnable)
            handler.postDelayed(restartRunnable, 300)     // let the rotation animation settle
        }
    }

    private fun doRestart() {
        if (!running) return
        val (w, h) = computeSize()
        if (w == curW && h == curH) return
        try {
            val oldC = codec; val oldS = inputSurface
            codec = null                                   // stops old drain thread
            vdisplay?.surface = null
            try { oldC?.stop() } catch (_: Exception) {}
            try { oldC?.release() } catch (_: Exception) {}
            try { oldS?.release() } catch (_: Exception) {}
            startEncoder(w, h, true)                       // old encoder is gone first: no concurrent-encoder limit
            vdisplay?.resize(w, h, resources.displayMetrics.densityDpi)
            vdisplay?.surface = inputSurface
        } catch (e: Throwable) {
            toast("Rotation failed: ${e.message}")
            stopAll()
        }
    }

    // ---------- misc ----------
    private fun toast(msg: String) {
        handler.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("mirror", "Streaming", NotificationManager.IMPORTANCE_LOW))
    }

    private fun stopAll(): Int {
        if (stopped) return START_NOT_STICKY
        stopped = true
        running = false
        handler.removeCallbacks(restartRunnable)
        try { getSystemService(DisplayManager::class.java).unregisterDisplayListener(displayListener) } catch (_: Exception) {}
        try { codec?.stop(); codec?.release() } catch (_: Exception) {}
        codec = null
        try { inputSurface?.release() } catch (_: Exception) {}
        try { vdisplay?.release() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        try { wifiLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        sent.clear()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        return START_NOT_STICKY
    }
}
