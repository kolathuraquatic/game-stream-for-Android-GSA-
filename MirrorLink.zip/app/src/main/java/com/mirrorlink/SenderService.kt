package com.mirrorlink

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Point
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.wifi.WifiManager
import android.os.*
import android.view.Display
import android.view.Surface
import java.net.*
import java.nio.ByteBuffer
import java.util.concurrent.locks.LockSupport
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Phone side: MediaProjection -> VirtualDisplay -> hardware encoder (surface input, zero copy)
 * -> UDP. Reacts to receiver feedback (keyframe requests, loss -> bitrate adaptation, RTT pings)
 * and re-creates the encoder on rotation.
 */
@Suppress("DEPRECATION")
class SenderService : Service() {
    companion object { const val ACTION_STOP = "stop" }

    private var projection: MediaProjection? = null
    private var vdisplay: VirtualDisplay? = null
    @Volatile private var codec: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var socket: DatagramSocket? = null
    private var target: InetSocketAddress? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private val lock = Any()
    @Volatile private var running = false
    private var stopped = false

    private var mime = MediaFormat.MIMETYPE_VIDEO_AVC
    private var fps = 60
    private var maxEdge = 1920
    private var maxBitrate = 20_000_000
    @Volatile private var bitrate = 20_000_000
    private var curW = 0
    private var curH = 0
    @Volatile private var config: ByteArray? = null
    private var frameId = 0
    private var lastKeyReq = 0L
    private var goodSeconds = 0

    private val pkt = ByteArray(Proto.HEADER + Proto.MAX_PAYLOAD)
    private val bb = ByteBuffer.wrap(pkt)
    private var dp: DatagramPacket? = null

    override fun onBind(i: Intent?): IBinder? = null
    override fun onDestroy() { stopAll() }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i == null || i.action == ACTION_STOP) return stopAll()
        stopped = false
        createChannel()
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, SenderService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "mirror")
            .setContentTitle("MirrorLink is streaming")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(Notification.Action.Builder(0, "Stop", stopPi).build())
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        mime = if (i.getBooleanExtra("hevc", false)) MediaFormat.MIMETYPE_VIDEO_HEVC else MediaFormat.MIMETYPE_VIDEO_AVC
        fps = i.getIntExtra("fps", 60)
        maxEdge = i.getIntExtra("edge", 1920)
        maxBitrate = i.getIntExtra("mbps", 20) * 1_000_000
        bitrate = maxBitrate
        val host = i.getStringExtra("host") ?: return stopAll()

        try {
            target = InetSocketAddress(host, Proto.PORT)
            socket = DatagramSocket().apply {
                sendBufferSize = 2 shl 20; trafficClass = 0xB8; soTimeout = 500
            }
            dp = DatagramPacket(pkt, pkt.size, target)
            wifiLock = (applicationContext.getSystemService(WIFI_SERVICE) as WifiManager)
                .createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "mirror-tx").also { it.acquire() }

            val mpm = getSystemService(MediaProjectionManager::class.java)
            val p = mpm.getMediaProjection(i.getIntExtra("code", 0), i.getParcelableExtra("data")!!)
            projection = p
            p.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopAll() } }, handler)

            running = true
            val (w, h) = captureSize()
            startEncoder(w, h, true)
            vdisplay = p.createVirtualDisplay(
                "mirror", w, h, resources.displayMetrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, inputSurface, null, null
            )
            getSystemService(DisplayManager::class.java).registerDisplayListener(displayListener, handler)
            Thread(::feedbackLoop, "mirror-fb").start()
        } catch (e: Exception) {
            return stopAll()
        }
        return START_NOT_STICKY
    }

    private fun captureSize(): Pair<Int, Int> {
        val d = getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
        val p = Point(); d.getRealSize(p)
        val s = min(1f, maxEdge.toFloat() / max(p.x, p.y))
        fun even(v: Float) = v.roundToInt() and 1.inv()
        return Pair(even(p.x * s), even(p.y * s))
    }

    private fun startEncoder(w: Int, h: Int, cbr: Boolean) {
        val c = MediaCodec.createEncoderByType(mime)
        val f = MediaFormat.createVideoFormat(mime, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
            setInteger(MediaFormat.KEY_BITRATE_MODE,
                if (cbr) MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR
                else MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
            setInteger(MediaFormat.KEY_PRIORITY, 0)               // realtime
            setInteger(MediaFormat.KEY_OPERATING_RATE, fps)
            setInteger("low-latency", 1)
            setInteger("latency", 1)
            setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 100_000L) // keep stream alive on static screens
        }
        try {
            c.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        } catch (e: Exception) {
            c.release()
            if (cbr) { startEncoder(w, h, false); return } else throw e
        }
        val s = c.createInputSurface()
        c.start()
        synchronized(lock) { codec = c; inputSurface = s; curW = w; curH = h; config = null }
        Thread({ drain(c) }, "mirror-enc").also { it.priority = Thread.MAX_PRIORITY }.start()
    }

    private fun drain(c: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        try {
            while (running && codec === c) {
                val i = c.dequeueOutputBuffer(info, 10_000)
                if (i < 0) continue
                val buf = c.getOutputBuffer(i)
                if (buf != null && info.size > 0) {
                    buf.position(info.offset); buf.limit(info.offset + info.size)
                    val data = ByteArray(info.size); buf.get(data)
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
                        config = data; sendConfig()
                    } else {
                        sendFrame(data, info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0, info.presentationTimeUs)
                    }
                }
                c.releaseOutputBuffer(i, false)
            }
        } catch (_: Exception) {}
    }

    private fun sendConfig() {
        val cfg = config ?: return
        val b = ByteBuffer.allocate(5 + cfg.size)
        b.put(if (mime == MediaFormat.MIMETYPE_VIDEO_HEVC) 1 else 0)
        b.putShort(curW.toShort()); b.putShort(curH.toShort()); b.put(cfg)
        sendPackets(Proto.T_CONFIG, 0, 0, 0, b.array())
    }

    private fun sendFrame(d: ByteArray, key: Boolean, ts: Long) {
        if (key) sendConfig()   // config precedes every IDR so a late-joining receiver can start
        sendPackets(Proto.T_VIDEO, if (key) Proto.F_KEY else 0, frameId++, ts, d)
    }

    private fun sendPackets(type: Int, flags: Int, fid: Int, ts: Long, d: ByteArray) {
        val s = socket ?: return
        val count = (d.size + Proto.MAX_PAYLOAD - 1) / Proto.MAX_PAYLOAD
        var off = 0
        for (idx in 0 until count) {
            val len = min(Proto.MAX_PAYLOAD, d.size - off)
            Proto.write(bb, type, flags, fid, idx, count, ts)
            bb.put(d, off, len)
            dp!!.setData(pkt, 0, Proto.HEADER + len)
            try { s.send(dp) } catch (_: Exception) {}
            off += len
            // pace big frames (keyframes) so we don't overflow switch / Wi-Fi buffers
            if (count > 12 && idx % 6 == 5) LockSupport.parkNanos(150_000)
        }
    }

    private fun feedbackLoop() {
        val buf = ByteArray(256)
        val rp = DatagramPacket(buf, buf.size)
        val out = ByteArray(Proto.HEADER)
        val ob = ByteBuffer.wrap(out)
        while (running) {
            rp.length = buf.size
            try { socket!!.receive(rp) }
            catch (e: SocketTimeoutException) { continue }
            catch (e: Exception) { break }
            val h = parseHeader(buf, rp.length) ?: continue
            when (h.type) {
                Proto.T_PING -> {
                    Proto.write(ob, Proto.T_PONG, 0, 0, 0, 1, h.ts)
                    try { socket!!.send(DatagramPacket(out, out.size, rp.socketAddress)) } catch (_: Exception) {}
                }
                Proto.T_REQ_KEY -> requestKey()
                Proto.T_STATS -> onStats(ByteBuffer.wrap(buf, Proto.HEADER, 8))
            }
        }
    }

    private fun requestKey() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastKeyReq < 150) return
        lastKeyReq = now
        setParam(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0)
    }

    private fun setParam(key: String, v: Int) {
        try { codec?.setParameters(Bundle().apply { putInt(key, v) }) } catch (_: Exception) {}
    }

    /** AIMD: back off fast on loss, creep up when clean. */
    private fun onStats(b: ByteBuffer) {
        val ok = b.int; val lost = b.int
        val total = ok + lost
        if (total == 0) return
        val loss = lost * 100f / total
        val raw = when {
            loss > 2f -> { goodSeconds = 0; (bitrate * 0.8f).toInt() }
            loss < 0.3f -> if (++goodSeconds >= 3) { goodSeconds = 0; bitrate + 1_000_000 } else bitrate
            else -> { goodSeconds = 0; bitrate }
        }
        val nr = raw.coerceIn(3_000_000, maxBitrate)
        if (nr != bitrate) { bitrate = nr; setParam(MediaCodec.PARAMETER_KEY_VIDEO_BITRATE, nr) }
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(id: Int) {}
        override fun onDisplayRemoved(id: Int) {}
        override fun onDisplayChanged(id: Int) {
            if (id != Display.DEFAULT_DISPLAY || !running) return
            val (w, h) = captureSize()
            if (w == curW && h == curH) return
            val oldC = codec; val oldS = inputSurface
            try {
                startEncoder(w, h, true)
                vdisplay?.resize(w, h, resources.displayMetrics.densityDpi)
                vdisplay?.surface = inputSurface
            } catch (_: Exception) {}
            try { oldC?.stop(); oldC?.release() } catch (_: Exception) {}
            oldS?.release()
        }
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("mirror", "Streaming", NotificationManager.IMPORTANCE_LOW))
    }

    private fun stopAll(): Int {
        if (stopped) return START_NOT_STICKY
        stopped = true
        running = false
        try { getSystemService(DisplayManager::class.java).unregisterDisplayListener(displayListener) } catch (_: Exception) {}
        try { codec?.stop(); codec?.release() } catch (_: Exception) {}
        codec = null
        try { inputSurface?.release() } catch (_: Exception) {}
        try { vdisplay?.release() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        try { wifiLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        return START_NOT_STICKY
    }
}
