package com.mirrorlink

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Diag.init(this)
        Diag.installCrashHandler()
    }
}
