package com.mirrorlink

import android.content.Context
import android.content.Intent

/** Everything the user can tune (scrcpy-style). Saved on the phone and passed to the service. */
class StreamSettings(
    var host: String = "",
    var edge: Int = 1920,        // max long edge: 1280 / 1920 / 2560 / 3840
    var fps: Int = 60,
    var mbps: Int = 20,
    var hevc: Boolean = false,
    var cbr: Boolean = true,
    var adaptive: Boolean = true,
    var orient: Int = 0,         // 0 auto, 1 landscape lock, 2 portrait lock
    var scale: Int = 0,          // on TV: 0 fit, 1 fill (crop), 2 stretch
    var net: Int = 0,            // 0 auto, 1 Wi-Fi, 2 wired
    var buffer: Int = 0,         // 0 lowest latency, 1 balanced, 2 smooth
    var iframe: Int = 4,         // keyframe interval, seconds
    var showStats: Boolean = true
) {
    fun putInto(i: Intent): Intent = i
        .putExtra("host", host).putExtra("edge", edge).putExtra("fps", fps).putExtra("mbps", mbps)
        .putExtra("hevc", hevc).putExtra("cbr", cbr).putExtra("adaptive", adaptive)
        .putExtra("orient", orient).putExtra("scale", scale).putExtra("net", net)
        .putExtra("buffer", buffer).putExtra("iframe", iframe).putExtra("stats", showStats)

    fun save(ctx: Context) {
        ctx.getSharedPreferences("settings", Context.MODE_PRIVATE).edit()
            .putString("host", host).putInt("edge", edge).putInt("fps", fps).putInt("mbps", mbps)
            .putBoolean("hevc", hevc).putBoolean("cbr", cbr).putBoolean("adaptive", adaptive)
            .putInt("orient", orient).putInt("scale", scale).putInt("net", net)
            .putInt("buffer", buffer).putInt("iframe", iframe).putBoolean("stats", showStats)
            .apply()
    }

    companion object {
        fun load(ctx: Context): StreamSettings {
            val p = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
            return StreamSettings(
                host = p.getString("host", "") ?: "",
                edge = p.getInt("edge", 1920), fps = p.getInt("fps", 60), mbps = p.getInt("mbps", 20),
                hevc = p.getBoolean("hevc", false), cbr = p.getBoolean("cbr", true),
                adaptive = p.getBoolean("adaptive", true), orient = p.getInt("orient", 0),
                scale = p.getInt("scale", 0), net = p.getInt("net", 0), buffer = p.getInt("buffer", 0),
                iframe = p.getInt("iframe", 4), showStats = p.getBoolean("stats", true)
            )
        }

        fun from(i: Intent): StreamSettings = StreamSettings(
            host = (i.getStringExtra("host") ?: "").trim(),
            edge = i.getIntExtra("edge", 1920).coerceIn(640, 3840),
            fps = i.getIntExtra("fps", 60).coerceIn(15, 120),
            mbps = i.getIntExtra("mbps", 20).coerceIn(2, 100),
            hevc = i.getBooleanExtra("hevc", false),
            cbr = i.getBooleanExtra("cbr", true),
            adaptive = i.getBooleanExtra("adaptive", true),
            orient = i.getIntExtra("orient", 0),
            scale = i.getIntExtra("scale", 0),
            net = i.getIntExtra("net", 0),
            buffer = i.getIntExtra("buffer", 0),
            iframe = i.getIntExtra("iframe", 4).coerceIn(1, 10),
            showStats = i.getBooleanExtra("stats", true)
        )
    }
}
